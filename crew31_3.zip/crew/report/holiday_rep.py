# -*- coding: utf-8 -*-
import time
from odoo import api, models ,_
from dateutil.parser import parse
from odoo.exceptions import UserError
from dateutil.relativedelta import relativedelta
from datetime import datetime,timedelta
from datetime import date
from odoo.exceptions import ValidationError


class holiday_rep(models.AbstractModel):
    _name = 'report.crew.holiday_rep_temp'

    @api.model
    def render_html(self, docids, data=None):
        print("!1111111111111111111111")
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_id'))
        orders=[]
        balance=[]
        date_format = '%Y-%m-%d'

        crew = self.env['crew.transaction']
        if docs.date_from and docs.date_to:
            if docs.date_from > docs.date_to:
                print("IIIIIIIIIIIIIIIIIIIIIIIIIIfff")
                raise ValidationError(
                    _("%s is not a valid range (%s > %s)") % (
                        self.date_from, self.date_to))
            else:
                if docs.employee_id:
                    crew = self.env['crew.transaction'].search([('onboard_date', '>=', docs.date_from),('onboard_date', '<=', docs.date_to),('employee_id', '=', docs.employee_id.id),('state', '=', 'in')])
                elif docs.crew_ids:
                    crew = self.env['crew.transaction'].search([('onboard_date', '>=', docs.date_from),('onboard_date', '<=', docs.date_to),('crew_ids', 'in', docs.crew_ids.ids),('state', '=', 'in')])
                elif docs.crew_ids and docs.employee_id:
                    crew = self.env['crew.transaction'].search([('onboard_date', '>=', docs.date_from),('onboard_date', '<=', docs.date_to),('employee_id', '=', docs.employee_id.id),('crew_ids', 'in', docs.crew_ids.ids),('state', '=', 'in')])
                else:
                    crew = self.env['crew.transaction'].search([('onboard_date', '>=', docs.date_from),('onboard_date', '<=', docs.date_to),('state', '=', 'in')])
                for x in crew:
                    # orders.append(x)
                    for l in self.env['hr.holidays'].search([('employee_id', '=', x.employee_id.id)]):
                        if docs.date_to >= l.date_from:
                            if docs.date_to >= l.date_to:
                                x.write({'balance' : l.number_of_days_temp })
                                orders.append(x)
                                print("1111111111111111111111")
                                # orders.append({'balance' : l.number_of_days_temp,
                                #                'employee_id' : x.employee_id,
                                #                'crew_ids' : x.crew_ids.id,
                                #                'project_trans_id' : x.project_trans_id.id,
                                #                'project_id' : x.project_id.id,
                                #                'onboard_date' : x.onboard_date,
                                #                'departure_date' : x.departure_date,
                                #                })
                            else:
                                print("2222222222222222222222222")
                                d1 = datetime.strptime(docs.date_to, date_format).date()
                                d2 = datetime.strptime(l.date_from, date_format).date()
                                d = d2 - d1
                                x.write({'balance' : d.days })
                                orders.append(x)
                                # orders.append({'balance' : d.days,
                                #                'employee_id' : x.employee_id.id,
                                #                'crew_ids' : x.crew_ids.id,
                                #                'project_trans_id' : x.project_trans_id.id,
                                #                'project_id' : x.project_id.id,
                                #                'onboard_date' : x.onboard_date,
                                #                'departure_date' : x.departure_date,
                                #                })

                        elif docs.date_to >= l.date_to:
                            if docs.date_from <= l.date_from:
                                print("33333333333333333333333")
                                x.write({'balance' : l.number_of_days_temp })
                                orders.append(x)
                                # orders.append({'balance' : l.number_of_days_temp,
                                #                'employee_id' : x.employee_id.id,
                                #                'crew_ids' : x.crew_ids.id,
                                #                'project_trans_id' : x.project_trans_id.id,
                                #                'project_id' : x.project_id.id,
                                #                'onboard_date' : x.onboard_date,
                                #                'departure_date' : x.departure_date,
                                #                })
                            else:
                                print("444444444444444444444444")

                                d1 = datetime.strptime(docs.date_from, date_format).date()
                                d2 = datetime.strptime(l.date_to, date_format).date()
                                d = d2 - d1
                                x.write({'balance' : l.number_of_days_temp })
                                orders.append(x)
                                # orders.append({'balance' : d.days,
                                #                'employee_id' : x.employee_id.id,
                                #                'crew_ids' : x.crew_ids.id,
                                #                'project_trans_id' : x.project_trans_id.id,
                                #                'project_id' : x.project_id.id,
                                #                'onboard_date' : x.onboard_date,
                                #                'departure_date' : x.departure_date,
                                #                })

        else:
            print("eeeeeeeeeeeeeeeelllllllllllllllllllllssssssssssssssssssssssss")
            raise UserError("Please enter duration")
        print(orders , "ordersordersordersordersorders")
        docargs = {
            'doc_ids': self.ids,
            'doc_model': self.model,
            'docs': docs,
            'time': time,
            'orders': orders
        }
        return self.env['report'].render('crew.holiday_rep_temp', docargs)
