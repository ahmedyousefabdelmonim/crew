# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrJobtype(models.Model):
    _name = 'hr.job.type'

    name = fields.Char(string='Name')
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.ref('base.USD'))
    job_type_tree = fields.One2many(comodel_name='hr.job.type_tree' , inverse_name='job_tree' ,string='Strcture')


class HrJobtypetree(models.Model):
    _name = 'hr.job.type_tree'

    job_tree = fields.Many2one('hr.job.type', 'Structure', readonly=True)
    title_id = fields.Many2one(comodel_name="hr.job", string="Job Title", required=False, )
    struct_id = fields.Many2one('hr.payroll.structure', 'Structure',)
    location_id = fields.Many2one(string="Location",comodel_name="project.type",required=False, )
    currency_id = fields.Many2one('res.currency', string="Currency" ,default=lambda self: self.env.ref('base.USD'))
    amount = fields.Float(string='Rate')






class HrJob_tit(models.Model):
    _inherit = 'hr.job'

    job_type = fields.Many2many(comodel_name='hr.job.type', string="Job Type", required=False, )

class hr_job_amount(models.Model):
    _name = 'hr.job.amount'

    amount = fields.Integer(string="Job Amount", required=False, )


class HrJob(models.Model):
    _name = 'hr.job.title'

    labor_id = fields.Many2one(comodel_name="hr.crew.labor", string="Labor", required=False, )
    title_id = fields.Many2one(comodel_name="hr.job", string="Title", required=False, )
    no_employees_req = fields.Integer(string="Number Requested", required=False, )
    no_employees_done = fields.Integer(string="Number Done", required=False, )
    state = fields.Selection(related='labor_id.state')


    @api.multi
    def write(self, values):
        if values.get('state') != 'draft' and values.get('no_employees_done') !=0:
            if values.get('no_employees_done') and int(values.get('no_employees_done')) < self.no_employees_req:
                values['state'] = 'partial'
            elif values.get('no_employees_done') and int(values.get('no_employees_done')) == self.no_employees_req:
                values['state'] = 'complete'
        return super(HrJob, self).write(values)


