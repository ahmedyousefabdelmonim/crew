# -*- coding: utf-8 -*-

from datetime import datetime,timedelta
from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta
from odoo import tools, _


class HrEmployee(models.Model):
    _inherit = 'hr.employee'
    _rec_name = 'temp_emp_num'

    _sql_constraints = [
        ('identification_id_uniq', 'unique (identification_id)', 'The Identification Number must be unique')
    ]

    temp_num = fields.Char(string="Num" , compute='get_num' )
    temp_emp_num = fields.Char(string="Num" , related='temp_num' , index=True , store=True)


    eng_name = fields.Char(string="English Name" , required=False , )

    emp_num = fields.Integer(string="Employee Number" , required=False , index=True)

    project_id = fields.Many2one(comodel_name="project.project", string="Last Assigned Project", required=False, )

    sick_leave = fields.Selection(string="Sick Leave", selection=[('1', 'Yes'), ('0', 'No'), ], required=False,store="True" ,
                                  compute='_compute_sick_leave')

    last_leave_date = fields.Date(string="Last Vacation Start Date", required=False,compute='_compute_last_leave_date' , store="True")
    last_leave_days = fields.Float(string="Last Vacation Days", required=False,compute='_compute_last_leave_date' , store="True")
    vacation = fields.Boolean(string="Vacation ",default=False ,  required=False,)
    cut_vac = fields.Date(string="Vacation End Date", required=False)
    last_vacation_id = fields.Many2one(comodel_name="hr.holidays", string="Last Vacation ID", required=False, )

    crew_admin_id = fields.Many2one(comodel_name="hr.employee", string="Crew Admin", required=False, )
    currency_id = fields.Many2one('res.currency', string='Currency',default=lambda self: self.env.user.company_id.currency_id.id, )

    out_source = fields.Boolean(string="Outsource" ,default=False ,  required=False,)
    freelancer = fields.Boolean(string="FreeLancer" ,default=False ,  required=False,)
    vendors = fields.Many2one(comodel_name='res.partner',string="Vendors" ,default=False , domain=[('supplier', '=', True)],)
    products = fields.Many2one(comodel_name='product.template',string="Products" ,default=False ,)
    # currency_id_outsource = fields.Many2one('res.currency', string='Currency',default=lambda self: self.env.user.company_id.currency_id.id, )

    outsource_rate = fields.Float(string="Rate")
    payslip_sheet = fields.One2many(comodel_name="hr.timesheet.crew", inverse_name="employee_payslip", string="Payslip", required=False, )

    holiday_balance = fields.Integer(string="Holiday Balance" ,required=False,)
    number_days = fields.Integer(string="Number Of Days" , required=False,)


    dedication_vodafone_co = fields.Float(string="Vodafone Co")
    dedication_vodafone_pe = fields.Float(string="Vodafone PE")
    dedication_mobinil_co = fields.Float(string="Mobinil CO")
    dedication_mobinil_pe = fields.Float(string="Mobinil PE")
    dedication_Etisalat_co = fields.Float(string="Etisalat CO")
    dedication_Etisalat_pe = fields.Float(string="Etisalat PE")
    dedication_car_insurance = fields.Float(string="Car Insurance")
    dedication_family_medical_insur = fields.Float(string="Family Medical")
    dedication_insurance = fields.Float(string="Insurance")
    dedication_satellite = fields.Float(string="Satellite")
    dedication_other_dedication = fields.Float(string="Other Dedication")
    dedication_outlay = fields.Float(string="Outlay")
    dedication_loans = fields.Float(string="Loans")
    dedication_course = fields.Float(string="Course")
    dedication_insurance_above60 = fields.Float(string="Insurance Above 60")

    leaves_annual = fields.Integer(string="Leaves Annual")
    leaves_years = fields.Integer(string="Years")
    year_calc = fields.Integer(string="Years")
    month_calc = fields.Integer(string="Years")
    leaves_allocation = fields.Integer(string="Leaves Allocation" , readonly=True , default=0)
    tot_leaves = fields.Integer(string="Total Leaves" , compute='count_leaves' , readonly=True , default=0)

    employee_national_id_pasport = fields.Boolean(string="3 Copies of the Employee’s national ID and passport",
                                                  default=False, )
    personal_photographes = fields.Boolean(string="8 personal photographs with white background", default=False, )
    educational_certificate = fields.Boolean(string="Original copies of Educational certificates, if any",
                                             default=False, )
    regestiration_cert_competent_labor_off = fields.Boolean(
        string="Registration certificate with the competent Labor Office", default=False, )
    medical_cert_est = fields.Boolean(
        string="A medical certificate establishing the Employee’s physical capacity for work Issued from El Nokrashy Hospital",
        default=False, )
    certificate_evidencing_termination = fields.Boolean(
        string="A certificate evidencing termination of the candidate's employment with the last Employer, if any",
        default=False, )
    social_insurance = fields.Boolean(string="Form (6) of social insurance from the last Employer, if any",
                                      default=False, )
    birth_certificate = fields.Boolean(string="Birth certificate", default=False, )
    criminal_certificate = fields.Boolean(string="Criminal record certificate", default=False, )
    military_status_certificate = fields.Boolean(string="Military status certificate for non Militarians males",
                                                 default=False, )
    experience_letter = fields.Boolean(
        string="original copy of an experience letter and a copy of the resume for a working officer", default=False, )
    naval_passport = fields.Boolean(string="a copy of the naval passport and the regular passport", default=False, )
    technical_professioncy_certificate = fields.Boolean(
        string="technical professioncy certificate and a Practicing license from the competent labor office for the following Jobs (Cook-Mechanic-Electrician-cooling and AC technician)",
        default=False, )
    obligatory_qualifying_documents = fields.Boolean(string="obligatory qualifying documents", default=False, )
    civil_certificate = fields.Boolean(
        string="Copy of the Civil certificate for (Chief Engineer-Captain-third engineer-Second engineer-Second officer)",
        default=False, )
    syndicate_membershib = fields.Boolean(
        string="copy of the syndicate membershib ID for (Accountants-Lawyers-Engineer-Doctors)", default=False, )


    @api.one
    def get_num(self):
        emp_name = self.name
        self.temp_num = '%s%s' % (self.emp_num and '[%s] ' % self.emp_num or '', emp_name)




    @api.one
    @api.depends()
    def count_leaves(self):
        print("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMm")
        count = self.env['hr.holidays'].search_count([('employee_id', '=', self.id) , ('holiday_status_id.name', 'not in', ["Crew" , "Unpaid"])])
        self.update({'tot_leaves' : count})


    def inc_years_num(self):
        print("inc_years_numinc_years_numinc_years_numinc_years_num")
        for x in self.env['hr.employee'].search([]):
            if x.year_calc <= x.leaves_years:
                print(x.year_calc <= x.leaves_years)
                temp = x.leaves_annual / 12
                print(x.leaves_annual , temp , "temptemptemp")
                if x.month_calc == 12 :
                    x.year_calc += 1
                    x.write({'month_calc': x.month_calc + 1,
                                 'year_calc': x.year_calc + 1,
                                 'leaves_allocation': x.leaves_allocation + temp})
                else:
                    x.write({'month_calc': x.month_calc + 1,
                                 'leaves_allocation': x.leaves_allocation + temp})
            else:
                x.write({'month_calc' : 0,
                             'year_calc' : 0,
                            'leaves_allocation' : 0})


    @api.one
    def _compute_sick_leave(self):
        leave_type = self.env.ref('hr_holidays.holiday_status_sl')
        leaves = self.env['hr.holidays'].search([('employee_id', '=', self.id),('holiday_status_id', '=', leave_type.id), ('state', 'in', ['validate', 'validate1'])])
        if leaves:
            self.sick_leave = '1'
        else:
            self.sick_leave = '0'

    @api.one
    def _compute_last_leave_date(self):
        leaves = self.env['hr.holidays'].search([('employee_id', '=', self.id),('type', '=', 'remove'),('state', 'in', ['validate', 'validate1'])],order='date_from')
        if leaves:
            for leave in leaves[-1]:
                self.last_leave_date = leave.date_from
                self.last_leave_days = leave.number_of_days_temp



    @api.multi
    def compute_vacation(self):
        date_format = '%Y-%m-%d %H:%M:%S'
        for emp in self.env['hr.employee'].search([]):
            if emp.vacation :
                        if emp.last_vacation_id:
                            print(emp.name, emp.vacation, emp.last_vacation_id.name, "****")
                            d = datetime.strptime(emp.last_vacation_id.date_to, date_format).date()

                            newdate_to = d + timedelta(days=1)

                            temp = emp.last_vacation_id.number_of_days_temp + 1
                            print(newdate_to, temp, "****")

                            emp.last_vacation_id.write({'date_to': newdate_to,
                                                        'number_of_days_temp': temp,
                                                        })