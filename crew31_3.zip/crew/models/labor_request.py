# -*- coding: utf-8 -*-

from odoo import models, fields, api,_
from odoo.exceptions import Warning
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

class CrewLabor(models.Model):
    _name = 'hr.crew.labor'
    _rec_name='ref'

    request_type = fields.Selection(string="Request Transaction Type", selection=[('mop', 'MOB'), ('demop', 'DEMOB'), ], required=True, )
    ref = fields.Char(string="Reference", required=True, copy=False, readonly=True, index=True, default=lambda self: _('New') )

    crew_id = fields.Many2one(comodel_name="hr.department", string="Crew Department",domain=[('is_crew','=',True)], required=False, )
    crew_num = fields.Integer(string="Number Of Req Member", required=False, )
    project_id = fields.Many2one(comodel_name="project.project" ,string="Project", required=False, )
    # project_type = fields.Many2one(string="Project Type", required=False,related='project_id.proj_type_id' )
    project_manager = fields.Many2one(string="Project Manager", required=False,related='project_id.user_id' )
    location_name = fields.Many2one(related='project_id.location_id')
    mob_num = fields.Integer(string="MOB Num", required=False,default=0 )
    demob_num = fields.Integer(string="DeMOB Num", required=False,default=0 )
    done_num = fields.Integer(string="MOP Num", required=False,default=0  , compute='get_done_emps')

    job_ids = fields.One2many(comodel_name="hr.job.title", inverse_name="labor_id", string="Titles", required=False, )

    date_onboard = fields.Date(string="Estimated Time OnBoard", required=False, )
    date_outboard = fields.Date(string="Estimated Departure Date", required=False, )
    reason = fields.Text(string="Reason", required=False, )
    state = fields.Selection(string="Status", selection=[('draft', 'Draft'), ('request', 'Requested'),('approved', 'Approved'),('partial', 'Partial Complete'),('complete', 'Complete'), ],default='draft', required=False, )
    lock = fields.Boolean(string="lock", default=False )
    temp_lock = fields.Boolean(default=False)

    crew_in = fields.Many2one(comodel_name="crew.in", required=False, )
    crew_out = fields.Many2one(comodel_name="crew.out", required=False, )

    milestone_id = fields.Many2one(comodel_name="project.milestone", required=False, )
    task_id = fields.Many2one(comodel_name="project.task", required=False, )
    sub_task_id = fields.Many2one(comodel_name="project.sub_task", required=False, )

    job_titles = fields.Many2many(comodel_name="hr.job", required=False, compute='get_titles' )

    # send_notifi = fields.Boolean(default=False )

    crew_manager = fields.Boolean(default=False , compute='visi_manager')

    @api.one
    @api.depends('job_ids')
    def visi_manager(self):

        if self.crew_id.manager_id.user_id.id == self.env.user.id and self.state == 'request':
            self.update({'crew_manager' : True})

    @api.depends('job_ids')
    def get_done_emps(self):
        for emp in self.job_ids:
                self.done_num +=  emp.no_employees_done

    @api.depends('job_ids')
    def get_titles(self):
        titles = []
        for emp in self.job_ids:
            titles.append(emp.title_id.id)

        self.update({'job_titles' :titles})



    # @api.depends('state')
    # def comp_lock(self):
    #     if self.state == 'complete' or self.temp_lock:
    #         print("#############################")
    #         self.lock = True

    def action_lock(self):
        self.update({'temp_lock' : True})

    # @api.multi
    # def write(self, values):
    #     print('--------values--------',values)
    #     # if values.get('state') != 'draft' and values.get('no_employees_done') != 0:
    #     #     if values.get('no_employees_done') and int(values.get('no_employees_done')) < self.no_employees_req:
    #     #         values['state'] = 'partial'
    #     #     elif values.get('no_employees_done') and int(values.get('no_employees_done')) == self.no_employees_req:
    #     #         values['state'] = 'complete'
    #     return super(CrewLabor, self).write(values)

    @api.multi
    def action_request(self):
        self.state = 'request'

    @api.multi
    def action_approve(self):
        self.state = 'approved'

    @api.multi
    def action_partial(self):
        self.state = 'partial'

    @api.multi
    def action_complete(self):
        self.state = 'complete'

    # @api.multi
    @api.constrains('crew_num','job_ids' , 'state')
    def _check_crew_number(self):
        print("UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU")
        num = 0
        for job in self.job_ids:
            num += job.no_employees_req
        print(num  , "nnnnnnnnnnnnnnnnnnnnnnnnnnn")
        print(self.crew_num  , "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM")
        if self.state == 'request':
            print("in if request")
            if num != self.crew_num:
                print("riggggggght")
                raise Warning(_('Number Of Req Member Must Equal Member of Titles'))

    # Override the Labor create function for generate MOP/DeMOP Unique number

    @api.model
    def create(self, values):

        num = values['crew_num']
        titles = ""
        recipient_partners = []
        temp=''
        count = 0
        for tit in values['job_ids']:

            for x in self.env['hr.job'].search([('id' , '=' , tit[2]['title_id'])]):
                if count !=0:
                    titles += " - ( " + str(x.name) + " : " + str(tit[2]['no_employees_req']) + " )"
                else:
                    titles += "( " + str(x.name) + " : " + str(tit[2]['no_employees_req']) + " )"
                count += 1

        # count = 0
        # for tit in values['job_titles']:
        #     for x in self.env['hr.job'].search([('id' , '=' , tit[2])]):
        #         print(x.name , "nnnnnnnnnnnnnnnnn")
        #         if count !=0:
        #             titles +=" - " + x.name
        #         else:
        #             titles += x.name
        #         count += 1
        #
        print(values.get('job_titles.ids') , "values['job_titles']values['job_titles']")
        # for tit in values['job_titles']:
        #     print(tit[2] , "ttttttitttttiiiiii")
        #     titles += self.env['hr.job'].search([('id' , '=' , tit[2] )]).name
        print(titles ,"titlestitlestitles")
        if values.get('request_type') == 'mop':
            values['ref'] =self.env['ir.sequence'].next_by_code('labor.mop.code')
        elif values.get('request_type') == 'demop':
            values['ref'] = self.env['ir.sequence'].next_by_code('labor.dmop.code')
        temp = values['ref']
        for x in self.env['hr.department'].search([('id' , '=' , values['crew_id'] )]):
            for y in self.env['res.users'].search([('id' , '=' , x.manager_id.user_id.id)]):
                recipient_partners.append(y.partner_id.id)
        print(recipient_partners , "recipient_partnersrecipient_partnersrecipient_partners")
        print("Labor request ( " + values['ref'] + " ) created , needs " + str(num) + " employees [ " + titles + " ] for your department . ")
        post_vars = {'subject': "Labor Request",
                     'body': "Labor request ( " + values['ref'] + " ) created , needs " + str(num) + " employees [ " + titles + " ] for your department . ",
                     'partner_ids': recipient_partners}
        thread_pool = self.env['mail.thread']
        thread_pool.message_post(
            type="notification",
            subtype="mt_comment",
            **post_vars)
        return super(CrewLabor, self).create(values)


    @api.multi
    def action_view_employees(self):
        # self.ensure_one()

        # if self.crew_in:
        #     view_id = self.env.ref('crew.crew_in_form')
        #     crew = self.crew_in.id
            domain = [('labor_request_id', '=', self.id)]
            return {
                'name': _('Employees'),
                'type': 'ir.actions.act_window',
                'res_model': 'hr.crew.labor.done',
                'view_type': 'form',
                'view_mode': 'tree',
                'domain': domain,
                'target': 'new'
            }
        # else:
        #     view_id = self.env.ref('crew.crew_out_form')
        #     crew = self.crew_out.id
        #     domain = [('id', '=', crew)]
        #     return {
        #         'name': _('Employees'),
        #         'domain': domain,
        #         'res_model': 'crew.out',
        #         'type': 'ir.actions.act_window',
        #         'view_id': view_id.id,
        #         'view_mode': 'form',
        #         'views':[(view_id.id,'form')],
        #         'view_type': 'form',
        #         'target': 'new',
        #         'res_id':self.crew_out.id if self.id else False
        #     }


class CrewLaborDone(models.Model):
    _name = 'hr.crew.labor.done'

    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=True, )
    project_id = fields.Many2one(comodel_name="project.project" ,string="Project", required=False, )
    # project_type = fields.Many2one(string="Project Type", required=False,related='project_id.proj_type_id' )
    location_id = fields.Many2one(related='project_id.location_id')
    project_shift_type_id = fields.Many2one(related='project_id.proj_shift_type_id')
    project_manager = fields.Many2one(string="Project Manager", required=False,related='project_id.user_id' )
    date_employee_added = fields.Datetime(string="Time", required=False, )
    labor_request_id = fields.Many2one(comodel_name="hr.crew.labor", string="Labor Request", required=False)



