# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions

class crew_settings(models.TransientModel):
    _name = 'crew.settings'
    _inherit = 'res.config.settings'


    reassign_per = fields.Integer(string="Period", required=False )


    @api.multi
    def set_default_generate_crew(self):
        return self.env['ir.values'].sudo().set_default(
            'crew.settings', 'reassign_per', self.reassign_per)



