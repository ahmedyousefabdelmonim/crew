# -*- coding: utf-8 -*-

from odoo import models, fields, api , _
from datetime import datetime,timedelta , date
import time
from datetime import timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError
from odoo.tools import float_compare, float_is_zero





class payslip_offshore_tree(models.Model):
    _name = 'payslip.offshore_tree'

    payslip = fields.Many2one(comodel_name='hr.payslip', string="Payslip", required=False,)

    project_id = fields.Many2one(comodel_name="project.project", string="Project Name", required=False, readonly=True  )
    location_id = fields.Many2one(string="Location",comodel_name="project.type",required=False, readonly=True  )
    rate = fields.Float(string="Rate",compute='get_rate')
    days = fields.Integer(string="Days", required=False, readonly=True )
    amount = fields.Float(string="Amount" , compute='get_amount')



    @api.one
    def get_amount(self):
        self.amount = self.days * self.rate

    @api.one
    @api.depends('project_id', 'location_id', 'payslip')
    def get_rate(self):
        currency = self.env['res.currency'].search([('name', '=', 'EGP')]).id
        rate = self.env.user.company_id.currency_id.rate
        # for job in self.payslip.payslip_offshre:
        # self.update({'rate': 99})
        for x in self.env['hr.offshore'].search([('job_titles' , '=' , self.payslip.employee_id.job_id.id),('struct_id' , '=' , self.payslip.struct_id.id),('location_id' , '=' , self.location_id.id)]):
            print(x.currency_id.id , currency ,"mmmmmmmm" , x.rate , "xxxxxxxxxxxxxxx*************************xxxxxxxxxxxxxxxxxxxx")
            if x.currency_id.id == currency:
                self.update({'rate': x.rate})
            else:
                self.update({'rate': ( self.env['res.currency'].search([('name', '=', 'EGP')]).rate * x.rate )})


class payslip_job_type(models.Model):
    _name = 'payslip.job_type'

    payslip = fields.Many2one(comodel_name='hr.payslip', string="Payslip", required=False,)

    job_type = fields.Many2one(comodel_name='hr.job.type' , string="Job Type", required=False, readonly=True )
    days = fields.Integer(string="Days", required=False, readonly=True )
    project_id = fields.Many2one(comodel_name="project.project", string="Project Name", required=False,         readonly=True  )
    location_id = fields.Many2one(string="Location",comodel_name="project.type",required=False, readonly=True  )
    rate = fields.Float(string="Rate",compute='get_rate')
    amount = fields.Float(string="Amount" , compute='get_amount')
    bounce = fields.Float(string="Bonus" , compute='get_bounce')


    @api.one
    def get_amount(self):
        self.amount = (self.days * self.bounce) + (self.days * self.rate)


    @api.one
    @api.depends('project_id', 'job_type')
    def get_bounce(self):
        for pro in self.project_id.project_bonus_ids:
            for tit in self.job_type.job_type_tree:
                if pro.job_titles.id == tit.title_id.id:
                    self.update({'bounce': pro.bonus})


    @api.one
    @api.depends('job_type', 'location_id', 'payslip')
    def get_rate(self):
        currency = self.env['res.currency'].search([('name', '=', 'EGP')]).id
        rate = self.env.user.company_id.currency_id.rate
        job_title = self.payslip.employee_id.job_id.id
        for job in self.payslip.payslip_job:
            for x in job.job_type.job_type_tree:
                print(x.struct_id.id , self.payslip.struct_id.id, "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
                if x.struct_id.id == self.payslip.struct_id.id and job.location_id.id == x.location_id.id and currency == x.currency_id.id:
                    print(job.location_id.id , x.location_id.id, "yyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy")
                    job.update({'rate': x.amount})
                elif x.struct_id.id == self.payslip.struct_id.id and job.location_id.id == x.location_id.id:
                    print(self.env['res.currency'].search([('name', '=', 'EGP')]).rate  , x.amount  , "zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz")
                    job.update({'rate': ( self.env['res.currency'].search([('name', '=', 'EGP')]).rate * x.amount )})


class HrPayslip(models.Model):
    _inherit = 'hr.payslip'

    date = fields.Date('Date Account', states={'draft': [('readonly', False)]}, readonly=True,
        help="Keep empty to use the period of the validation(Payslip) date.")
    journal_id = fields.Many2one('account.journal', 'Salary Journal', readonly=True, required=True,
        states={'draft': [('readonly', False)]}, default=lambda self: self.env['account.journal'].search([('type', '=', 'general')], limit=1))
    move_id = fields.Many2one('account.move', 'Accounting Entry', readonly=True, copy=False)


    from_time_sheet = fields.Boolean(default=False)
    timesheet_datefrom =  fields.Date(string='Date From', required=False, default=str(datetime.now() + relativedelta(months=-1, day=1, days=+15))[:10])
    timesheet_dateto =  fields.Date(string='Date To', required=False, default=time.strftime('%Y-%m-15'), )
    attendance_datefrom =  fields.Date(string='Date From', required=False,default=str(datetime.now() + relativedelta(months=0, day=1, days=+19))[:10])
    attendance_dateto =  fields.Date(string='Date To', required=False,default=str(datetime.now() + relativedelta(months=1, day=1, days=+18))[:10])
    performance = fields.Integer(string="Performance", required=False, compute='onchange_employee_id_new' )
    bonus = fields.Float(string="Bonus", required=False, compute='get_bonus')
    allowance_down_payment = fields.Float(string="Allowance Down Payment" , compute='get_down_payment')

    days = fields.Integer(string="Days", required=False, compute='onchange_employee_id_new' )
    offshore = fields.Integer(string="2x Offshore", required=False)
    breakfast_loc = fields.Float(string="Breakfast", required=False, compute='onchange_employee_id_new'  )
    lunch_loc = fields.Float(string="Lunch", required=False, compute='onchange_employee_id_new' )
    dinner_loc = fields.Float(string="Dinner", required=False, compute='onchange_employee_id_new'  )
    lodge_loc = fields.Float(string="Lodge", required=False, compute='onchange_employee_id_new'  )

    loan_amount = fields.Float(string='Loan Amount' , compute='get_loan_amount' )


    away_loc = fields.Float(string='Away' , required=False, compute='onchange_employee_id_new' )
    away_inter = fields.Float(string='Away' , required=False, compute='onchange_employee_id_new' )
    car_loc = fields.Float(string='Car' , required=False, compute='onchange_employee_id_new' )
    car_inter = fields.Float(string='Car' , required=False, compute='onchange_employee_id_new' )
    days_loc = fields.Integer(string='Days' , required=False, compute='onchange_employee_id_new' )
    days_inter = fields.Integer(string='Days' , required=False, compute='onchange_employee_id_new' )

    breakfast_inter = fields.Float(string="Breakfast", required=False, compute='onchange_employee_id_new'  )
    lunch_inter = fields.Float(string="Lunch", required=False, compute='onchange_employee_id_new'  )
    dinner_inter = fields.Float(string="Dinner", required=False, compute='onchange_employee_id_new'  )
    lodge_inter = fields.Float(string="Lodge", required=False, compute='onchange_employee_id_new'  )
    ass_project =  fields.Many2many("project.project", string="Projects", required=False, compute='onchange_employee_id_new')
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.ref('base.USD') , readonly=True)
    job_id = fields.Many2one(comodel_name='hr.job', string="Job Title",related='employee_id.job_id', required=False,)
    # job_type = fields.Many2many(comodel_name='hr.job.type', string="Job Type", required=False, readonly=True )
    payslip_job = fields.One2many(comodel_name='payslip.job_type',inverse_name="payslip", compute='get_payslip_job_offshre' , store=True)
    payslip_offshre = fields.One2many(comodel_name='payslip.offshore_tree',inverse_name="payslip", compute='get_payslip_job_offshre' , store=True)


    # job_type = fields.Many2one(comodel_name='hr.job.type', string="Job Type", required=False, readonly=True )
    # job_type_amount = fields.Monetary(string="Job Type Amount", required=False, related='job_type.amount' , readonly=True )


    current_month = fields.Integer(compute='get_current_moth')
    current_year = fields.Integer(string="Year" , compute='get_current_moth')

    tot_amount_jobtype = fields.Float(string='Job Type Amount' , compute='get_tot_amout_jobtype')
    tot_amount_offshore = fields.Float(string='Offshore Amount' , compute='get_tot_amout_offshore')

    @api.depends('payslip_job' , 'struct_id')
    def get_tot_amout_jobtype(self):
        tot=0.0
        for job in self.payslip_job:
            tot +=job.amount
        self.update({'tot_amount_jobtype': tot })


    @api.one
    @api.depends('date_from' , 'date_to' , 'employee_id' , 'struct_id')
    def get_loan_amount(self):
        for x in self.env['hr.loan'].search([('employee_id' , '=' , self.employee_id.id),('state' , '=' , "approve")]).loan_lines:
            if self.date_from <= x.date and self.date_to >= x.date:
                    self.loan_amount = x.amount


    @api.depends('payslip_offshre' , 'struct_id')
    def get_tot_amout_offshore(self):
        tot=0.0
        for off in self.payslip_offshre:
            tot +=off.amount
        self.update({'tot_amount_offshore': tot })

    # @api.onchange('job_type' , 'days')
    # def onchange_job_days(self):
    #     vals=[]
    #     if self.job_type:
    #         vals.append(
    #             (0, 0, {
    #              'job_type':self.job_type.id,
    #              'days':self.days,}))
    #         print(vals ,"valsvalsvalsvals")
    #         self.update({'payslip_job':vals})

    # @api.one
    # @api.depends('employee_id' , 'ass_project' , 'date_from' , 'date_to')
    # def get_away(self):
    #     for leave in self.env['hr.holidays'].search([('employee_id' , '=' , self.employee_id.id)]):
    #         if leave.payslip_type == "local":
    #             if self.timesheet_dateto >= leave.date_to and self.timesheet_datefrom <= leave.date_from:
    #                 self.away_loc = leave.away
    #                 self.away_loc = leave.away
    #         if leave.payslip_type == "international":
    #             if self.timesheet_dateto >= leave.date_to and self.timesheet_datefrom <= leave.date_from:
    #                 self.away_inter = leave.away

    @api.one
    @api.depends('date_to')
    def get_current_moth(self):
        date_format = '%Y-%m-%d'
        d1 = datetime.strptime(self.date_to, date_format).date()

        # print(d1.month)
        self.current_month = d1.month
        self.current_year = d1.year



    @api.depends('employee_id' , 'ass_project')
    def get_bonus(self):
        for proj in self.ass_project:
            for title in proj.project_bonus_ids:
                if self.employee_id.job_id.id == title.job_titles.id:
                    self.update({'bonus': title.bonus })

    # pay.date >= self.date_from and pay.date <= self.date_from

    @api.depends('employee_id' , 'date_from' , 'date_to')
    def get_down_payment(self):
        for pay in self.env['payment.request'].search([('allowance_down_payment' , '=' , True),('partner_id_employee' , '=' , self.employee_id.id)]):
                if pay.dedication_period == 'current_month' :
                    if pay.date >= self.date_from and pay.date <= self.date_to :
                        if pay.currency_id.name == "EGP":
                            self.update({'allowance_down_payment': pay.amount })
                        else:
                            # print(pay.amount , self.env['res.currency'].search([('name', '=', 'EGP')]).rate, "MMMMMMMMMMM")
                            self.update({'allowance_down_payment': pay.amount * self.env['res.currency'].search([('name', '=', 'EGP')]).rate})

                else:
                    if pay.dedication_period == 'next_month':
                        if pay.next_date >= self.date_from and pay.next_date <= self.date_to :
                            if pay.currency_id.name == "EGP":
                                self.update({'allowance_down_payment': pay.amount})
                            else:
                                print(pay.amount/self.env['res.currency'].search([('name', '=', 'EGP')]).rate , "MMMMMMMMMMM")
                                self.update({'allowance_down_payment': pay.amount * self.env['res.currency'].search([('name', '=', 'EGP')]).rate})



    @api.one
    @api.depends('employee_id' , 'timesheet_datefrom' , 'timesheet_dateto' , 'date_from' , 'date_to' , 'struct_id')
    def get_payslip_job_offshre(self):

        job_type = []
        offshore_list = []

        if self.employee_id :
            for emp in self.employee_id.payslip_sheet:
                if emp.current_year == self.current_year and emp.current_month == self.current_month :

                    job_type.append(
                        (0, 0, {
                            'job_type': emp.job_type.id,
                            'project_id': emp.project_id.id,
                            'location_id': emp.project_id.location_id.id,
                            'days': emp.days, }))
                    offshore_list.append(
                        (0, 0, {
                            'project_id': emp.project_id.id,
                            'location_id': emp.project_id.location_id.id,
                            'days': emp.offshore, }))

            self.update({
                         'payslip_offshre' : offshore_list,
                         'payslip_job': job_type,
                         })


    @api.one
    @api.depends('employee_id' , 'timesheet_datefrom' , 'timesheet_dateto' , 'date_from' , 'date_to')
    def onchange_employee_id_new(self):
        proj = []
        days = 0
        perform = []
        performance = 0
        temp_per = 0
        offshore = 0
        breakfast_loc = 0.0
        lunch_loc = 0.0
        dinner_loc = 0.0
        lodge_loc = 0.0
        away_loc = 0.0
        car_loc = 0.0
        breakfast_inter = 0.0
        lunch_inter = 0.0
        dinner_inter = 0.0
        lodge_inter = 0.0
        away_inter = 0.0
        car_inter = 0.0
        job_type = []
        offshore_list = []
        timesheet_datefrom = date.today()
        timesheet_dateto = date.today()
        co = 0
        days_loc = 0
        days_inter = 0

        if self.employee_id :
            for leave in self.env['hr.holidays'].search([('employee_id' , '=' , self.employee_id.id)]):
                if (leave.date_from >= self.timesheet_datefrom and leave.date_to <= self.timesheet_dateto) and leave.allowance:
                    if leave.payslip_type == "local":
                        breakfast_loc += leave.breakfast
                        lunch_loc += leave.lunch
                        dinner_loc += leave.dinner
                        lodge_loc += leave.lodge
                        away_loc += leave.away
                        car_loc += leave.car
                    if leave.payslip_type == "international":
                        breakfast_inter += leave.breakfast
                        lunch_inter += leave.lunch
                        dinner_inter += leave.dinner
                        lodge_inter += leave.lodge
                        away_inter += leave.away
                        car_inter += leave.car
            print(breakfast_inter , lunch_inter , dinner_inter , lodge_inter, "I(IINNNNNTRERtion" )
            print(breakfast_loc , lunch_loc , dinner_loc , lodge_loc, "Looooooooooooocallllll" )
            for emp in self.employee_id.payslip_sheet:
                if emp.current_year == self.current_year and emp.current_month == self.current_month :
                    co +=1
                    proj.append(emp.project_id.id)
                    days += emp.days
                    offshore = emp.offshore
                    perform.append(emp.performance)
                    temp_per += emp.performance
                    performance = temp_per/ len(perform)
                    print(perform , "performperformperformperformperformperform")
                    print(temp_per , len(perform) , "temp_per/ len(perform)temp_per/ len(perform)temp_per/ len(perform)")
                    if co == 1:
                        timesheet_datefrom = emp.date_from
                        timesheet_dateto = emp.date_to
                    else:
                        if emp.date_from < timesheet_datefrom :
                            timesheet_datefrom = emp.date_from
                        if emp.date_to > timesheet_dateto :
                            timesheet_dateto = emp.date_to
                    # job_type.append(emp.job_type.id)

                    if emp.project_id.location_id.name == 'Local':
                        breakfast_loc += emp.breakfast
                        lunch_loc += emp.lunch
                        dinner_loc += emp.dinner
                        lodge_loc += emp.lodge
                        days_loc += emp.days
                    elif emp.project_id.location_id.name == 'International':
                        breakfast_inter += emp.breakfast
                        lunch_inter += emp.lunch
                        dinner_inter += emp.dinner
                        lodge_inter += emp.lodge
                        days_inter += emp.days

            self.update({'ass_project' : [(4, x) for x in proj],
                         'days' : days,
                         'performance' : performance,
                         # 'job_type': [(4, x) for x in job_type],
                         'timesheet_datefrom' : timesheet_datefrom,
                         'timesheet_dateto' : timesheet_dateto,
                         'breakfast_loc' : breakfast_loc,
                         'lunch_loc' : lunch_loc,
                         'dinner_loc' : dinner_loc,
                         'lodge_loc' : lodge_loc,
                         'away_loc' : away_loc,
                         'car_loc' : car_loc,
                         'days_loc' : days_loc,
                         'breakfast_inter' : breakfast_inter,
                         'lunch_inter' : lunch_inter,
                         'dinner_inter' : dinner_inter,
                         'lodge_inter' : lodge_inter,
                         'away_inter' : away_inter,
                         'car_inter' : car_inter,
                         'days_inter' : days_inter,
                         })

    @api.model
    def create(self, vals):
        if 'journal_id' in self.env.context:
            vals['journal_id'] = self.env.context.get('journal_id')
        return super(HrPayslip, self).create(vals)

    @api.onchange('contract_id')
    def onchange_contract(self):
        super(HrPayslip, self).onchange_contract()
        self.journal_id = self.contract_id.journal_id.id or (not self.contract_id and self.default_get(['journal_id'])['journal_id'])

    @api.multi
    def action_payslip_cancel(self):
        moves = self.mapped('move_id')
        moves.filtered(lambda x: x.state == 'posted').button_cancel()
        moves.unlink()
        return super(HrPayslip, self).action_payslip_cancel()

    @api.multi
    def action_payslip_done(self):
        precision = self.env['decimal.precision'].precision_get('Payroll')
        move = self.env['account.move']
        for slip in self:
            line_ids = []
            debit_sum = 0.0
            credit_sum = 0.0
            date = slip.date or slip.date_to

            name = _('Payslip of %s') % (slip.employee_id.name)
            move_dict = {
                'narration': name,
                'ref': slip.number,
                'journal_id': slip.journal_id.id,
                'date': date,
            }
            for line in slip.details_by_salary_rule_category:
                amount = slip.credit_note and -line.total or line.total
                if float_is_zero(amount, precision_digits=precision):
                    continue
                debit_account_id = line.salary_rule_id.account_debit.id
                credit_account_id = line.salary_rule_id.account_credit.id

                if debit_account_id:
                    debit_line = (0, 0, {
                        'name': line.name,
                        'partner_id': line._get_partner_id(credit_account=False),
                        'account_id': debit_account_id,
                        'journal_id': slip.journal_id.id,
                        'date': date,
                        'debit': amount > 0.0 and amount or 0.0,
                        'credit': amount < 0.0 and -amount or 0.0,
                        'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                        'tax_line_id': line.salary_rule_id.account_tax_id.id,
                    })
                    line_ids.append(debit_line)
                    debit_sum += debit_line[2]['debit'] - debit_line[2]['credit']

                if credit_account_id:
                    credit_line = (0, 0, {
                        'name': line.name,
                        'partner_id': line._get_partner_id(credit_account=True),
                        'account_id': credit_account_id,
                        'journal_id': slip.journal_id.id,
                        'date': date,
                        'debit': amount < 0.0 and -amount or 0.0,
                        'credit': amount > 0.0 and amount or 0.0,
                        'analytic_account_id': line.salary_rule_id.analytic_account_id.id,
                        'tax_line_id': line.salary_rule_id.account_tax_id.id,
                    })
                    line_ids.append(credit_line)
                    credit_sum += credit_line[2]['credit'] - credit_line[2]['debit']

            if float_compare(credit_sum, debit_sum, precision_digits=precision) == -1:
                acc_id = slip.journal_id.default_credit_account_id.id
                if not acc_id:
                    raise UserError(_('The Expense Journal "%s" has not properly configured the Credit Account!') % (slip.journal_id.name))
                adjust_credit = (0, 0, {
                    'name': _('Adjustment Entry'),
                    'partner_id': False,
                    'account_id': acc_id,
                    'journal_id': slip.journal_id.id,
                    'date': date,
                    'debit': 0.0,
                    'credit': debit_sum - credit_sum,
                })
                line_ids.append(adjust_credit)

            elif float_compare(debit_sum, credit_sum, precision_digits=precision) == -1:
                acc_id = slip.journal_id.default_debit_account_id.id
                if not acc_id:
                    raise UserError(_('The Expense Journal "%s" has not properly configured the Debit Account!') % (slip.journal_id.name))
                adjust_debit = (0, 0, {
                    'name': _('Adjustment Entry'),
                    'partner_id': False,
                    'account_id': acc_id,
                    'journal_id': slip.journal_id.id,
                    'date': date,
                    'debit': credit_sum - debit_sum,
                    'credit': 0.0,
                })
                line_ids.append(adjust_debit)
            if self.employee_id.freelancer == False:
                move_dict['line_ids'] = line_ids
                move = self.env['account.move'].create(move_dict)
                slip.write({'move_id': move.id, 'date': date})
            else:
                tot = 0.0
                for net in self.line_ids:
                    if net.name == "Net":
                        tot = net.total
                self.env['payment.request'].create({
                    'department_id':slip.employee_id.department_id.id,
                    'partner_id_type':"employee",
                    'partner_id_employee':slip.employee_id.id,
                    'payment_method':"bank",
                    'date': datetime.today(),
                    'amount':tot,
                })
            move.post()
        return super(HrPayslip, self).action_payslip_done()









