# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions

class report_holiday_wizard(models.TransientModel):
    _name = 'report_holiday.wizard'
    _description = "Holiday Report Wizard"



    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=False, )
    crew_ids = fields.Many2many(comodel_name="hr.department", string="Crew", domain=[('is_crew', '=', True)],
                                required=False, )
    date_from = fields.Date(string="Date From", required=False, )
    date_to = fields.Date(string="Date To", required=False, )

    @api.multi
    def check_report(self):
        data = {}
        data['form'] = self.read(['employee_id', 'crew_ids' , 'date_from', 'date_to'])[0]
        return self._print_report(data)

    def _print_report(self, data):
        data['form'].update(self.read(['employee_id', 'crew_ids' , 'date_from', 'date_to'])[0])
        return self.env['report'].get_action(self, 'crew.holiday_rep_temp', data=data)





