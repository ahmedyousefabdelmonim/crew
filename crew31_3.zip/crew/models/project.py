# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions

class assignd_crew(models.Model):
    _name = 'assigned.crew'

    crew_id = fields.Many2one(comodel_name="hr.department", string="Crew", domain="[('is_crew','=',True)]", required=False, )
    manager_id = fields.Many2one(comodel_name="hr.employee",related='crew_id.crew_admin_id' ,  string="Crew Admin", required=False, )
    project_crew_id = fields.Many2one(comodel_name="project.crew", string="", required=False, )

    @api.multi
    @api.onchange('crew_id')
    def get_crew_manager(self):
        if self.crew_id:
            self.manager_id = self.crew_id.manager_id.id


class project_crew(models.Model):
    _name = 'project.crew'
    _rec_name = 'project_id'

    project_id = fields.Many2one(comodel_name="project.project", string="Project Name", required=False, )
    project_manager_id = fields.Many2one(comodel_name="res.users", string="Project Manager", required=False, )
    crew = fields.Integer(string="Crew", required=False, )
    assignd_crew_ids = fields.One2many(comodel_name="assigned.crew", inverse_name="project_crew_id", string="Assigned Crew ", required=False, )

    _sql_constraints = [
        ('project_uniq', 'UNIQUE (project_id)', 'You can not have two Project with the same project name !')
    ]

    @api.multi
    @api.onchange('project_id')
    def get_project_manager(self):
        if self.project_id:
            self.project_manager_id = self.project_id.user_id.id

    @api.multi
    @api.onchange('assignd_crew_ids')
    def get_crew_number(self):
        self.crew = len(self.assignd_crew_ids)

