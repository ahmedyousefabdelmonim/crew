# -*- coding: utf-8 -*-

from odoo import models, fields, api

class HrOffshore(models.Model):
    _name = 'hr.offshore'

    job_titles = fields.Many2one(comodel_name="hr.job" ,string="Job Title",  )
    location_id = fields.Many2one(string="Project Type",comodel_name="project.type",)
    struct_id = fields.Many2one(comodel_name='hr.payroll.structure', string='Structure')
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.ref('base.USD'))
    rate = fields.Float(string='Rate')

# class HrOffshoretree(models.Model):
#     _name = 'hr.offshore_tree'
#
#     job_tree = fields.Many2one('hr.job.type', 'Structure', readonly=True)
#
#     struct_id = fields.Many2one('hr.payroll.structure', 'Structure',)
#     location_id = fields.Many2one(string="Location",comodel_name="project.type",required=False, )
#     currency_id = fields.Many2one('res.currency', string="Currency" ,default=lambda self: self.env.ref('base.USD'))
#     amount = fields.Float(string='Rate')
#
