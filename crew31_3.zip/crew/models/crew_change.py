# -*- coding: utf-8 -*-

from datetime import datetime,timedelta
from datetime import date

from mock.mock import self

from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta


class crew_in(models.Model):
    _name = 'crew.in'
    _rec_name = 'project_id'

    project_id = fields.Many2one(comodel_name="project.project", string="Project Name", required=False, )
    project_type_id = fields.Selection(related='project_id.type_ids')
    project_shift_type_id = fields.Many2one(related='project_id.proj_shift_type_id')
    location_id = fields.Many2one(related='project_id.location_id')
    crew_ids = fields.Many2many(comodel_name="hr.department", string="Crew", domain=[('is_crew', '=', True)],
                                required=False, )
    employee_ids = fields.One2many(comodel_name="crew.transaction.in", inverse_name="crew_in_id", string="Members",
                                   required=False, )
    transaction_count = fields.Integer(compute='_transaction_count', string='# Transactions')
    crew_out = fields.Many2one(comodel_name="crew.out", string="Crew Out", required=False, )
    crew_reassign = fields.Many2one(comodel_name="crew.reassign", string="Crew Reassign", required=False, )
    state = fields.Selection(string="Status", selection=[('draft', 'Draft'), ('open', 'Open'), ('close', 'Close'), ],
                             required=False, default='draft')
    reassign = fields.Char(string="Reassign")

    _sql_constraints = [
        ('project_uniq', 'UNIQUE (project_id)', 'You can not have two Project with the same name !'),
    ]

    @api.multi
    def action_open(self):
        self.write({'state': 'open'})
        self.crew_out.action_open()
        self.crew_reassign.action_open()

    @api.multi
    def action_close(self):
        self.write({'state': 'close'})
        self.crew_out.action_close()
        self.crew_reassign.action_close()

    @api.multi
    def create_crew_out(self, crew , emps):
        print("create_crew_out" ,emps )
        vals = {
            'project_id': crew.project_id.id,
            'crew_in' : crew.id,
            'employee_ids': emps,
        }
        crew_out = self.env['crew.out'].create(vals)
        return crew_out
    @api.multi
    def write_crew_out(self, crew , emps):
        print("create_crew_out" ,emps )
        vals = {
            'employee_ids': emps,
        }
        crew_out = self.env['crew.out'].search([('project_id.id', '=', self.project_id.id)]).employee_ids.unlink()
        crew_out = self.env['crew.out'].search([('project_id.id', '=', self.project_id.id)]).write(vals)
        return crew_out

    @api.multi
    def write_crew_reassign(self, crew , emps):
            vals = {
                'employee_ids': emps,
            }
            crew_reassign = self.env['crew.reassign'].search([('project_id.id', '=', self.project_id.id)]).employee_ids.unlink()
            crew_reassign = self.env['crew.reassign'].search([('project_id.id', '=', self.project_id.id)]).write(vals)
            return crew_reassign

    @api.multi
    def create_crew_reassign(self, crew , emps):

        vals = {
            'project_id': crew.project_id.id,
            'employee_ids': emps,
        }
        crew_reassign = self.env['crew.reassign'].create(vals)
        return crew_reassign



    @api.multi
    def write(self, values):
        employee_out=[]
        res = super(crew_in, self).write(values)

        for emp in self:
            for e in emp.employee_ids:
                d = datetime.strptime(e.onboard_date, '%Y-%m-%d').date()
                new_departure_date = d + timedelta(days=1)
                employee_out.append(
                    (0, 0, {
                            'employee_id':e.employee_id.id,
                            'job_id': e.employee_id.job_id.id,
                            'job_type': e.job_type.id,
                            'doc_state': e.doc_state,
                            'cert_state':e.cert_state,
                            'project_id.id': e.project_id.id,
                            'onboard_date': e.onboard_date,
                            'departure_date': new_departure_date,

                    }))
        # print(employee_out , "UUUU")
        if self.state == 'open' and self.employee_ids:
            crew_out = self.write_crew_out(res , employee_out )
            crew_reassign = self.write_crew_reassign(res , employee_out )
        return res


    @api.model
    def create(self, values):
        employee_out=[]
        res = super(crew_in, self).create(values)
        for emp in res:
            for e in emp.employee_ids:
                d = datetime.strptime(e.onboard_date, '%Y-%m-%d').date()
                new_departure_date = d + timedelta(days=1)
                employee_out.append(
                    (0, 0, {
                            'employee_id':e.employee_id.id,
                            'job_id': e.employee_id.job_id.id,
                            'job_type' : e.job_type.id,
                            'doc_state': e.doc_state,
                            'cert_state':e.cert_state,
                            'project_id.id': e.project_id.id,
                            'onboard_date': e.onboard_date,
                            'departure_date': new_departure_date,
                            'trans_confirmed_d': e.trans_confirmed_d,

                    }))
        # print(employee_out , "UUUU")
        crew_out = self.create_crew_out(res , employee_out )

        # self.env['crew.out'].write({'employee_ids':employee_out})
        crew_reassign = self.create_crew_reassign(res , employee_out )
        res.crew_out = crew_out.id
        res.crew_reassign = crew_reassign.id
        return res

    @api.multi
    def unlink(self):
        for record in self :
            if record.state != 'draft':
                raise UserError(_('You cannot Delete the Project that is not Draft.'))
            record.crew_out.unlink()
            record.crew_reassign.unlink()
        return super(crew_in, self).unlink()

    @api.multi
    def _transaction_count(self):
        for each in self:
            transactions = self.env['crew.transaction'].search([('crew_in_id', '=', self.id), ('state', '=', 'in')])
            each.transaction_count = len(transactions)

    @api.multi
    @api.onchange('project_id', 'crew_ids')
    def onchange_project_id(self):
        project = self.env['project.crew'].search([('project_id', '=', self.project_id.id)])
        crew = project.assignd_crew_ids.mapped('crew_id')
        return {'domain': {'crew_ids': [('id', 'in', crew.ids)]}}

    @api.constrains('employee_ids')
    def onchange_employee_ids(self):
       employees1 = self.employee_ids.mapped('employee_id').ids
       employees2 = [mem.employee_id.id for mem in self.employee_ids]

       employees3 = self.search([('state','!=','close')])
       for mem in employees3:
           print(mem.project_id.name , "mmmmmmmmmmmmmmmmmmmm")
           for emp in mem.employee_ids:
               print(emp.employee_id.name, "EEEEEEEEEEEEEEEEEEEEEEEEEE")

       employees_list1 = [emp.employee_id.id for mem in employees3 for emp in mem.employee_ids]
       employees_list1.sort()
       employees_list2 = list(set(employees_list1))
       employees2.sort()
       print(employees_list1 , "employees_list1employees_list1employees_list1employees_list1employees_list1")
       print(employees_list2 , "employees_list2employees_list2employees_list2employees_list2employees_list2")
       print(len(employees_list1) > len(employees_list2) , "employees_list1 > employees_list2")
       if employees2 > employees1:
           raise UserError(_('You cannot Create Many Record With Same Employee.'))

       elif len(employees_list1) > len(employees_list2):
           raise UserError(_('You cannot Assign Employee on Many Project In same Time.'))

    @api.multi
    def action_view_transaction(self):
        self.ensure_one()
        domain = [('crew_in_id', '=', self.id), ('state', '=', 'in')]
        return {
            'name': _('Transactions'),
            'domain': domain,
            'res_model': 'crew.transaction',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">
                                   Click to Create for New Transactions
                                </p>'''),
            'limit': 80,
        }


class CrewOut(models.Model):
    _name = 'crew.out'
    _rec_name = 'project_id'

    crew_in = fields.Many2one(comodel_name="crew.in", required=False, )
    project_id = fields.Many2one(comodel_name="project.project", string="Project Name", required=False, )
    project_type_id = fields.Selection(related='project_id.type_ids')
    project_shift_type_id = fields.Many2one(related='project_id.proj_shift_type_id')
    location_id = fields.Many2one(related='project_id.location_id')
    employee_ids = fields.One2many(comodel_name="crew.transaction.out", inverse_name="crew_out_id", string="Members",
                                   required=False, )
    transaction_count = fields.Integer(compute='_transaction_count', string='# Transactions')
    state = fields.Selection(string="Status", selection=[('draft', 'Draft'), ('open', 'Open'), ('close', 'Close'), ],
                             required=False, default='draft')
    reassign = fields.Char(string="Reassign")

    employees = fields.Many2many(comodel_name="hr.employee", string="Employee Name",default=False)



    @api.multi
    def confirm_button_multiselection(self):
        count=0
        dep_date=''
        flag = False
        employees = []
        leave = "Normal Leave"
        out = self.employee_ids.search([('select', '=', True)])

        for trans in out:
            if count == 0:
                dep_date = str(trans.departure_date)
                count +=1
            if str(trans.departure_date) != dep_date:
                flag = True
        if flag == True:
            raise UserError(_('Departure Date are different.'))
            return 0
        else:
                for record in out:
                    employees.append(record.employee_id.id)
                    record.select = False
                return {
                    'type': 'ir.actions.act_window',
                    'res_model': 'out.line.confirm.multiselection',
                    'view_type': 'form',
                    'view_mode': 'form',
                    'context': {
                        'default_employee_id': employees,
                                'default_out_id': self.id,
                                'default_departure_date': dep_date,
                    },
                    'target': 'new'}





    @api.multi
    def action_open(self):
        self.write({'state': 'open'})

    @api.multi
    def action_close(self):
        self.write({'state': 'close'})

    @api.multi
    def _transaction_count(self):
        for each in self:
            transactions = self.env['crew.transaction'].search([('crew_out_id', '=', self.id), ('state', '=', 'out')])
            each.transaction_count = len(transactions)

    @api.multi
    def action_view_transaction(self):
        self.ensure_one()
        domain = [('crew_out_id', '=', self.id), ('state', '=', 'out')]
        return {
            'name': _('Transactions'),
            'domain': domain,
            'res_model': 'crew.transaction',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">
                                       Click to Create for New Transactions
                                    </p>'''),
            'limit': 80,
        }


class CrewReassign(models.Model):
    _name = 'crew.reassign'
    _rec_name = 'project_id'

    project_id = fields.Many2one(comodel_name="project.project", string="Project Name", required=False, )
    project_type_id = fields.Selection(related='project_id.type_ids')
    project_shift_type_id = fields.Many2one(related='project_id.proj_shift_type_id')
    location_id = fields.Many2one(related='project_id.location_id')
    employee_ids = fields.One2many(comodel_name="crew.transaction.reassign", inverse_name="crew_reassign_id",
                                   string="Members", required=False, )
    transaction_count = fields.Integer(compute='_transaction_count', string='# Transactions')
    state = fields.Selection(string="Status", selection=[('draft', 'Draft'), ('open', 'Open'), ('close', 'Close'), ],
                             required=False, default='draft')


    def compute_datetoday(self):

        for crew in self.env['crew.reassign'].search([('state' , '=' , 'open')]):
            for line in crew.employee_ids:
                if line.onboard_date == date.today():
                    d = datetime.strptime(line.onboard_date, '%Y-%m-%d').date()
                    line.departure_date = d + timedelta(days=1)
                else:
                    line.departure_date = date.today()


    @api.multi
    def action_open(self):
        self.write({'state': 'open'})

    @api.multi
    def action_close(self):
        self.write({'state': 'close'})

    @api.multi
    def _transaction_count(self):
        for each in self:
            transactions = self.env['crew.transaction'].search(
                [('crew_reassign_id', '=', self.id), ('state', '=', 'reassign')])
            each.transaction_count = len(transactions)

    @api.multi
    def action_view_transaction(self):
        self.ensure_one()
        domain = [('crew_reassign_id', '=', self.id), ('state', '=', 'reassign')]
        return {
            'name': _('Transactions'),
            'domain': domain,
            'res_model': 'crew.transaction',
            'type': 'ir.actions.act_window',
            'view_id': False,
            'view_mode': 'tree,form',
            'view_type': 'form',
            'help': _('''<p class="oe_view_nocontent_create">
                                       Click to Create for New Transactions
                                    </p>'''),
            'limit': 80,
        }


class CrewTransactionIn(models.Model):
    _name = 'crew.transaction.in'


    crew_in_id = fields.Many2one(comodel_name="crew.in", string="Crews", required=False, )
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", required=True, )
    # temp_employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee", )
    labor_request_id = fields.Many2one(comodel_name="hr.crew.labor", string="Labor Request", required=False,domain=[('state' , 'not in', ['complete' , 'draft']) , ('lock' , '!=' , 'True'), ('request_type' , '=' , 'mop')] )
    job_id = fields.Many2one(comodel_name='hr.job',required=True,)
    doc_state = fields.Selection(related='employee_id.doc_state')
    cert_state = fields.Selection(related='employee_id.cert_state')
    project_id = fields.Many2one(related='employee_id.project_id' , readonly=True)
    # crew_in_project_id = fields.Many2one(related='crew_in_id.project_id' , readonly=True)
    vacation_date = fields.Date(related='employee_id.last_leave_date')
    vacation_days = fields.Float(related='employee_id.last_leave_days')
    onboard_date = fields.Date(string="Onboard Start Date", required=True)
    sick_leave = fields.Selection(related='employee_id.sick_leave')
    is_confirm = fields.Boolean(string="Is Confirm", default=False)
    state = fields.Selection(related='crew_in_id.state')
    reassign = fields.Char(string="Reassign")
    trans_cancelled = fields.Boolean(default=False)
    trans_confirmed_d = fields.Char(default="Tarnsaction Confirmed in : ")
    temp_type = fields.Many2many(related='job_id.job_type')
    job_type = fields.Many2one(comodel_name='hr.job.type', string="Job Type", required=False, domain="[('id','in',temp_type[0][2])]" )

    @api.onchange('temp_type')
    def onchange_temp_type(self):
        temp_list=[]
        # print("UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        # print(self.temp_type.id ,self.temp_type.ids , "UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        if self.temp_type.ids == []:
            print("IOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}
        else:
            for x in self.temp_type:
                temp_list.append(x.id)
            print("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}


    # @api.onchange('crew_in_project_id')
    # def onchange_project(self):
    #     print("OOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
    #     la_req = []
    #     if self.crew_in_id.project_id:
    #         for labors in self.env['hr.crew.labor'].search():
    #             la_req.append(labors.id)
    #         print(la_req , "la_reqla_reqla_reqla_reqla_reqla_req")
    #         return {'domain': {'labor_request_id': [('id', 'in', la_req)]}}
    @api.onchange('labor_request_id')
    def onchange_labor_req(self):
        tit = []
        self.onboard_date = self.labor_request_id.date_onboard
        for title in self.labor_request_id.job_ids:
            tit.append(title.title_id.id)
        if self.labor_request_id:
            return {'domain': {'job_id': [('id', 'in', tit)]}}

    @api.multi
    @api.onchange('job_id')
    def onchange_job_id(self):
        emps = []
        open_emps = []
        for proj in self.env['crew.in'].search([('state', '=', 'open')]):
            for emp in proj.employee_ids:
                open_emps.append(emp.employee_id)

        for employee in self.env['hr.employee'].search([('job_id' , '=' , self.job_id.id )]):
                if employee not in open_emps:
                    emps.append(employee.id)

        if self.job_id:
            return {'domain': {'employee_id': [('id', 'in', emps)]}}
    @api.multi
    def confirm_in(self):

        current_user= self.env['res.users'].search([('id' , '=' , self.env.uid)])


        if self.labor_request_id:
          for labor in self.labor_request_id:
            for req in labor.job_ids:
                if req.title_id.id == self.job_id.id:
                    if labor.request_type == 'mop':
                        if labor.state != 'draft' and req.no_employees_done != 0:
                            print("111111111111111111111111111111111111111")
                            if req.no_employees_done and req.no_employees_done == req.no_employees_req:
                                labor.write({'lock': True,})
                                print("2222222222222222222222222222222222222222222")

                        req.write({'no_employees_done' : req.no_employees_done + 1 ,})

                        labor.write({'crew_in' : self.crew_in_id.id })

                    print(req.title_id , "&&&&&&&&&&&&&&&&&&&&&&&&&")



        if self.crew_in_id.project_id:
            self.employee_id.write({'project_id': self.crew_in_id.project_id.id})
        for record in self:
            d = datetime.strptime(record.onboard_date, '%Y-%m-%d').date()
            record.employee_id.vacation = False
            record.employee_id.cut_vac = d - timedelta(days=1)
            transaction = self.env['crew.transaction']
            vals = {
                'employee_id': record.employee_id.id,
                'crew_in_id': record.crew_in_id.id,
                'transaction_date': self.trans_confirmed_d + str(datetime.now()) + " By : " + str(current_user.name),
                'labor_request_id': record.labor_request_id.id,
                'project_trans_id': record.crew_in_id.project_id.id,
                'departure_date' : False,
                'onboard_date': record.onboard_date,
                'temp_onboard_date': record.onboard_date,
                'state': 'in',
                'reassign': record.reassign,
                'job_type' : record.job_type.id,
                'crew_ids' : record.employee_id.department_id.id
            }
            transaction.create(vals)
            if record.labor_request_id:
                self.env['hr.crew.labor.done'].create({
                    'labor_request_id':record.labor_request_id.id,
                    'employee_id':record.employee_id.id,
                    'project_id':record.crew_in_id.project_id.id,
                    'date_employee_added':datetime.now(),
                })
            record.is_confirm = True



    # @api.onchange()




    # @api.onchange('employee_id')
    # def _onchange_employee_id(self):
    #     employees_in = self.env['crew.in'].search([('project_id', '=', self.crew_in_id.project_id.id)])
    #     emps1 = []
    #     emps2 = []
    #     final_list =[]
    #     if self.crew_in_id.crew_ids:
    #         employees = []
    #         for crew in self.crew_in_id.crew_ids:
    #
    #                 employees.append(crew.employee_ids.ids)
    #         emps1 = [item for employee in employees for item in employee]
    #         for crew in self.env['crew.in'].search([('project_id', '=', self.crew_in_id.project_id.id)]):
    #             for c in crew.employee_ids:
    #                 emps2.append(c.employee_id.id)
    #         final_list = set(emps1) - set(emps2)
    #
    #     else:
    #         in_id = self.env['crew.in'].browse(self.env.context.get('active_ids'))
    #         for emp in self.env['hr.employee'].search([]):
    #             emps1.append(emp.id)
    #
    #         for crew in self.env['crew.in'].search([('project_id', '=', self.crew_in_id.project_id.id)]):
    #             for c in crew.employee_ids:
    #                 emps2.append(c.employee_id.id)
    #         final_list = set(emps1) - set(emps2)
    #     final_list = list(set(final_list))
    #
    #     return {'domain': {'employee_id': [('id', 'in', final_list)]}}
    #
    #
    # @api.onchange('employee_id','labor_request_id')
    # def _get_labor_id(self):
    #     final_list =[]
    #     tit_list=[]
    #     if self.labor_request_id:
    #         for emp in self.labor_request_id.job_ids:
    #             tit_list.append(emp.title_id.id)
    #     if self.job_id.id not in tit_list:
    #         self.labor_request_id = False
    #     if self.job_id:
    #         for req in self.env['hr.crew.labor'].search([('state' , 'not in', ['complete' , 'draft']) , ('lock' , '!=' , 'True'), ('request_type' , '=' , 'mop')]):
    #             for emp in req.job_ids:
    #                 print("BBBBBBBBBBEEEEEEEEEEEEEFFFFFFFFFFFOOOOOOOOORRRRRRRR")
    #                 if self.job_id.id == emp.title_id.id:
    #                     final_list.append(req.id)
    #                     print(req.ref , "RRRRRRRRRRRRRRRRRREEEEEEEEEEEEEEEEEEEEEEFFFFFFFFFFFFFFFFFFFFFFFF")
    #
    #
    #     return {'domain': {'labor_request_id': [('id', 'in', final_list)]}}




class out_line_confirm_multiselection(models.Model):
    _name = 'out.line.confirm.multiselection'


    employee_id = fields.Many2many(comodel_name="hr.employee", string="Employee Name", required=True, )
    departure_date = fields.Date(string="Debarture Date", required=True, )
    normal_leave = fields.Boolean(string="Normal" , default=True)
    sick_leave = fields.Boolean(string="Sick" , default=False)
    out_id =  fields.Many2one(comodel_name="crew.out")


    @api.onchange('normal_leave' )
    def onchange_normal_leave(self):

            if self.sick_leave and self.normal_leave:
                    self.normal_leave  = True
                    self.sick_leave  = False
            if not self.sick_leave and self.normal_leave :
                self.normal_leave = True
                self.sick_leave = False

    @api.onchange('sick_leave')
    def onchange_sick_leave(self):
            if self.normal_leave and self.sick_leave:
                    self.sick_leave  = True
                    self.normal_leave  = False
            if not self.normal_leave and self.sick_leave :
                self.sick_leave = True

    @api.multi
    def confirm_leave_out(self):
        holiday_status_id = 0
        date_format = '%Y-%m-%d'
        # d = datetime.strptime(self.departure_date, date_format).date()
        #
        # newdate_from = fields.Date.from_string(self.departure_date) + timedelta(days=1)

        newdate_from = (datetime.strptime(self.departure_date, date_format) + relativedelta(days=+1))
        print(newdate_from , "&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")

        for x in self.env['hr.holidays.status'].search([('name', '=', "Sick Leaves")]):
            holiday_status_id = x.id


        # out_id = self.env['crew.out'].browse(self.env.context.get('active_ids'))

        if self.normal_leave:
            leave = "Normal Leave"
            for emp in self.employee_id:
                print(emp , "empempempempempempempempemp")
                for out in self.out_id.employee_ids.search([('employee_id' , '=' , emp.id)]):
                    out.update({'departure_date':self.departure_date})
                    out.confirm_out(leave)
        if self.sick_leave:
            leave = "Sick Leave"
            for emp in self.employee_id:
                for out in self.out_id.employee_ids.search([('employee_id' , '=' , emp.id)]):
                    out.temp = True
                    out.update({'departure_date':self.departure_date})
                    out.confirm_out(leave)
                return {
                    'type': 'ir.actions.act_window',
                    'res_model': 'hr.holidays',
                    'view_type': 'form',
                    'view_mode': 'form',
                    'context': {
                        'default_holiday_status_id': holiday_status_id,
                        'default_employee_id': emp.id,
                        'default_date_from': str(newdate_from)
                    },
                    'target': 'new'}







class CrewTransactionOut(models.Model):
    _name = 'crew.transaction.out'

    select = fields.Boolean(default=False  , store=True , string="Select")
    crew_out_id = fields.Many2one(comodel_name="crew.out", string="Crews", required=False, )
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee Name", required=True, )
    labor_request_id = fields.Many2one(comodel_name="hr.crew.labor", string="Labor Request", required=False,domain=[('state' , 'not in', ['complete' , 'draft']) , ('lock' , '!=' , 'True'), ('request_type' , '=' , 'demop')] )
    job_id = fields.Many2one(related='employee_id.job_id')
    doc_state = fields.Selection(related='employee_id.doc_state')
    cert_state = fields.Selection(related='employee_id.cert_state')
    project_id = fields.Many2one(related='employee_id.project_id')
    vacation_date = fields.Date(related='employee_id.last_leave_date')
    vacation_days = fields.Float(related='employee_id.last_leave_days')
    onboard_date = fields.Date(string="Onboard Start Date",required=False,)
    departure_date = fields.Date(string="Departure Date" )
    onboard_days = fields.Float(string="Onboard Days",compute='get_onboard_days')
    sick_leave = fields.Selection(related='employee_id.sick_leave')
    state = fields.Selection(related='crew_out_id.state')
    reassign = fields.Char(string="Reassign")
    is_reassign = fields.Boolean(string="Is Reassign", default=False)
    is_confirm_out = fields.Boolean(string="Is Confirm", default=False)
    temp = fields.Boolean(string="Is Confirm", default=False)
    trans_cancelled = fields.Boolean(default=False)
    trans_confirmed_d = fields.Char(default="Tarnsaction Confirmed in : ")
    temp_type = fields.Many2many(related='job_id.job_type')
    job_type = fields.Many2one(comodel_name='hr.job.type', string="Job Type", required=False, domain="[('id','in',temp_type[0][2])]" )





    @api.multi
    def confirm_button_action(self):
        return {
            'name': _('Confirm Out Request'),
            'type': 'ir.actions.act_window',
            'res_model': 'out.line.confirm',
            'view_type': 'form',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_employee_id':self.employee_id.id,
                'default_out_id':self.crew_out_id.id,
                'default_departure_date':self.departure_date,
            }
        }







    @api.onchange('temp_type')
    def onchange_temp_type(self):
        temp_list=[]
        print("UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        print(self.temp_type.id ,self.temp_type.ids , "UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        if self.temp_type.ids == []:
            print("IOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}
        else:
            for x in self.temp_type:
                temp_list.append(x.id)
            print("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}


    #
    #
    # # @api.one
    # @api.multi
    # def bulk_verify(self):
    #     print("functionfunctionfunctionfunctionfunctionfunctionfunctionfunctionfunction")
    #     count=0
    #     dep_date=''
    #     flag = False
    #     employees = []
    #     crew_out = 0
    #     leave = "Normal Leave"
    #
    #     for trans in self:
    #         if count == 0:
    #             dep_date = str(trans.departure_date)
    #             crew_out = trans.crew_out_id.id
    #             count +=1
    #         if str(trans.departure_date) != dep_date:
    #             print("TrueTrueTrueTrueTrueTrueTrueTrue")
    #             flag = True
    #         print(dep_date ,"dep_datedep_datedep_datedep_datedep_datedep_datedep_date")
    #         print(trans.departure_date ,"departure_datedeparture_datedeparture_datedeparture_date")
    #         print(flag ,"flagflagflagflagflagflagflagflagflagflagflagflagflag")
    #     if flag == True:
    #         raise UserError(_('Departure Date are different.'))
    #         return 0
    #     else:
    #         for record in self:
    #             # record.confirm_out(leave)
    #             employees.append(record.employee_id.id)
    #         #     record.crew_out_id.update({'employees' : employees})
    #         for record in self:
    #             print(record.crew_out_id.id ,"employeesemployeesemployeesemployeesemployeesemployeesemployees")
    #             out = self.env['crew.out'].search([('id' , '=' ,record.crew_out_id.id)])
    #             out.update({'employees' : employees})
    #             print(out,"elseelseelseelseelseelseelseelse")
    #         # for record in self:
    #         #     employees.append(record.employee_id.id)
    #         # print(employees , "employeesemployeesemployeesemployeesemployeesemployees")
    #         # view_id = self.env.ref('crew.out_line_confirm_multiselection_view')
    #         # return {
    #         #     'type': 'ir.actions.act_window',
    #         #     'res_model': 'out.line.confirm.multiselection',
    #         #     'view_type': 'form',
    #         #     'view_mode': 'form',
    #         #     # 'view_id': view_id.id,
    #         #     # 'views': [(view_id.id, 'form')],
    #         #     # 'res_id': self.id if self.id else False,
    #         #     # 'context': {
    #         #     #     'default_employee_id': employees,
    #         #     #     'default_out_id': crew_out,
    #         #     #     'default_departure_date': dep_date,
    #         #     # },
    #         #     'target': 'new'}
    #


    @api.onchange('labor_request_id')
    def onchange_labor_req(self):
        self.departure_date = self.labor_request_id.date_outboard


    @api.one
    def get_onboard_days(self):
        if self.onboard_date and self.departure_date :
            start_date = datetime.strptime(str(self.onboard_date),'%Y-%m-%d')
            end_date = datetime.strptime(str(self.departure_date),'%Y-%m-%d')
            period_days = end_date - start_date
            self.onboard_days = period_days.days+1



    @api.constrains('onboard_date','departure_date')
    def check_dates(self):
        if self.departure_date:
            if self.onboard_date > self.departure_date:
                raise UserError(_('OnBoard Date Must Be Before Departure Date.'))


    @api.model
    def create(self, values):
        res = super(CrewTransactionOut, self).create(values)
        employees_in = self.env['crew.in'].search([('project_id', '=', res.crew_out_id.project_id.id)], limit=1)
        for line in employees_in.employee_ids:
            if line.employee_id.id == res.employee_id.id:
                res.onboard_date = line.onboard_date
        return res

    # @api.multi
    # def reassign(self):



    #
    @api.multi
    def confirm_out(self , leave):
        current_user= self.env['res.users'].search([('id' , '=' , self.env.uid)])
        past_work = 0
        print("IIIIIIIIIIIIIIIII")
        if self.labor_request_id:
          for labor in self.labor_request_id:
            for req in labor.job_ids:
                if req.title_id.id == self.job_id.id:
                    print("333333333333333333")
                    if labor.request_type == 'demop':
                        if labor.state != 'draft' and req.no_employees_done != 0:
                            if req.no_employees_done and int(req.no_employees_done) == req.no_employees_req:
                                labor.write({'lock': True,})
                        print("QWEQQQQQQQQQQQQQQQQQWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW")
                        req.write({'no_employees_done' : req.no_employees_done + 1 ,})
                        labor.write({'crew_out': self.crew_out_id.id})
                    print(req.title_id , "&&&&&&&&&&&&&&&&&&&&&&&&&")

        if not self.departure_date:
            raise UserError(_('Departure Date Must Be Assigned Before Confirmation.'))
        else:

            print("BBBBBBBBBBBBBBBBBBBBBBBBB")
            if not self.temp and not self.is_reassign :
                print("CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC")
                for x in self.env['hr.holidays.status'].search([('name', '=', "Crew")]):
                    holiday_status_id = x.id
                self.employee_id.vacation = True

                for record in self:

                    hloiday = self.env['hr.holidays']
                    date_format = '%Y-%m-%d'
                    newdate_from = (datetime.strptime(self.departure_date , date_format)+ relativedelta(days=+1))
                    newdate_to =  (datetime.strptime(self.departure_date , date_format)+ relativedelta(days=+1))
                    holiday_val={
                        'name' : record.employee_id.name + " Crew Vacation",
                        'holiday_status_id' :holiday_status_id,
                        'repeat_every' : 'workday',
                        'date_from' : newdate_from,
                        'date_to': newdate_to,
                        'number_of_days_temp': 1,
                        'employee_id' : record.employee_id.id,

                    }
                    vac_id = hloiday.create(holiday_val)
                    print(vac_id)
                    self.employee_id.last_vacation_id= vac_id.id
                    transaction = self.env['crew.transaction']
                    for pp in self.env['crew.transaction'].search([('crew_in_id' , '=' ,record.crew_out_id.crew_in.id ), ('employee_id','=', self.employee_id.id,)]):
                        print(pp , "pppppppppppppppppppppppppppppppppppppppp")
                        past_work = pp.past_work
                        pp.write({'crew_out_id': record.crew_out_id.id,})
                    print("@#EWhgfhgfhgfgfdsese5445454545454545454545454545454")
                    # for pp in self.env['crew.transaction'].search([]):
                    #     print(pp , "pppppppppppppppppppppppppppppppppppppppp")
                    #     print(pp.crew_in_id , "pppppppppppppppppppppppppppppppppppppppp")
                    #     print(record.crew_out_id.crew_in , "pppppppppppppppppppppppppppppppppppppppp")

                        # ('crew_in_id', '=', record.crew_out_id.crew_in.id)
                        # if self.employee_id.id == pp.employee_id.id:
                            # pp.write({'crew_out_id': record.crew_out_id.id,})

                    vals = {
                        'employee_id': record.employee_id.id,
                        'crew_out_id': record.crew_out_id.id,
                        'project_trans_id': record.crew_out_id.project_id.id,
                        'onboard_date': record.onboard_date,
                        'departure_date': record.departure_date,
                        'onboard_days': record.onboard_days,
                        'temp_departure_date': record.departure_date,
                        'temp_onboard_date': self.env['crew.transaction'].search([('employee_id.id', '=', self.employee_id.id) , ('project_id.id', '=',self.project_id.id) , ('state' , '=' , "in")]).temp_onboard_date,
                        'state': 'out',
                        'reassign': record.reassign,
                        'transaction_date': self.trans_confirmed_d + str(datetime.now()) + " By : " + str(
                            current_user.name),
                        'past_work' : past_work,
                        'leave': leave,
                        'crew_ids': record.employee_id.department_id.id

                    }
                    transaction.create(vals)
                    self.env['crew.transaction'].search([('crew_in_id', '=', record.crew_out_id.crew_in.id),
                                                         ('employee_id', '=', self.employee_id.id,)]).write({'departure_date': record.departure_date,})
                    employees_in = self.env['crew.in'].search([('project_id', '=', record.crew_out_id.project_id.id)], limit=1)
                    employees_reassign = self.env['crew.reassign'].search([('project_id', '=', record.crew_out_id.project_id.id)], limit=1)
                    for emp in employees_in.employee_ids:
                        if emp.employee_id.id == record.employee_id.id:
                            emp.unlink()
                    if record.labor_request_id:
                        self.env['hr.crew.labor.done'].create({
                            'labor_request_id': record.labor_request_id.id,
                            'employee_id': record.employee_id.id,
                            'project_id': record.crew_out_id.project_id.id,
                            'date_employee_added': datetime.now(),
                        })
                    record.is_confirm_out = True
                    for re in employees_reassign.employee_ids.search([('employee_id', '=', self.employee_id.id)]):
                        re.unlink()
                    record.unlink()
            elif self.temp or self.is_reassign:
                    print("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD")

                    for record in self:
                        transaction = self.env['crew.transaction']
                        # if leave == "Sick Leave":
                        for pp in self.env['crew.transaction'].search(
                                [('crew_in_id', '=', record.crew_out_id.crew_in.id),
                                 ('employee_id', '=', self.employee_id.id,)]):
                            print(pp, "pppppppppppppppppppppppppppppppppppppppp")
                            past_work = pp.past_work
                            pp.write({'crew_out_id': record.crew_out_id.id, })
                        vals = {
                            'employee_id': record.employee_id.id,
                            'job_type': record.job_type.id,
                            'crew_out_id': record.crew_out_id.id,
                            'project_trans_id': record.crew_out_id.project_id.id,
                            'onboard_date': record.onboard_date,
                            'departure_date': record.departure_date,
                            'onboard_days': record.onboard_days,
                            'temp_departure_date': record.departure_date,
                            'temp_onboard_date': self.env['crew.transaction'].search([('employee_id.id', '=', self.employee_id.id) , ('project_id.id', '=',self.project_id.id) , ('state' , '=' , "in")]).temp_onboard_date,
                            'state': 'out',
                            'reassign': record.reassign,
                            'transaction_date': self.trans_confirmed_d + str(datetime.now()) + " By : " + str(
                                current_user.name),
                            'past_work' : past_work,
                            'leave':leave,
                            'crew_ids': record.employee_id.department_id.id

                        }
                        print(vals ,"vals")
                        transaction.create(vals)
                        employees_in = self.env['crew.in'].search(
                            [('project_id', '=', record.crew_out_id.project_id.id)], limit=1)
                        employees_reassign = self.env['crew.reassign'].search(
                            [('project_id', '=', record.crew_out_id.project_id.id)], limit=1)

                        for emp in employees_in.employee_ids:
                            if emp.employee_id.id == record.employee_id.id:
                                emp.unlink()
                        if record.labor_request_id:
                            self.env['hr.crew.labor.done'].create({
                                'labor_request_id': record.labor_request_id.id,
                                'employee_id': record.employee_id.id,
                                'project_id': record.crew_out_id.project_id.id,
                                'date_employee_added': datetime.now(),
                            })
                        record.is_confirm_out = True
                        for re in employees_reassign.employee_ids.search([('employee_id', '=', self.employee_id.id)]):
                            re.unlink()
                        record.unlink()


        return


    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        employees_in = self.env['crew.in'].search([('project_id', '=', self.crew_out_id.project_id.id)], limit=1)
        employees = employees_in.employee_ids.filtered(lambda rec: rec.is_confirm and rec.state == 'open').mapped('employee_id')
        return {'domain': {'employee_id': [('id', 'in', employees.ids)]}}


    @api.onchange('employee_id' , 'labor_request_id')
    def _get_labor_id(self):
        final_list =[]
        if self.job_id:
            for req in self.env['hr.crew.labor'].search([('state' , 'not in', ['complete' , 'draft']) , ('lock' , '!=' , 'True'), ('request_type' , '=' , 'demop')]):
                for emp in req.job_ids:
                    print("BBBBBBBBBBEEEEEEEEEEEEEFFFFFFFFFFFOOOOOOOOORRRRRRRR")
                    if self.job_id.id == emp.title_id.id:
                        final_list.append(req.id)
                        print(req.ref , "RRRRRRRRRRRRRRRRRREEEEEEEEEEEEEEEEEEEEEEFFFFFFFFFFFFFFFFFFFFFFFF")
                    else:
                        self.labor_request_id = False
        return {'domain': {'labor_request_id': [('id', 'in', final_list)]}}

class CrewTransactionReassign(models.Model):
    _name = 'crew.transaction.reassign'

    crew_reassign_id = fields.Many2one(comodel_name="crew.reassign", string="Crews", required=False, )
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee Name", required=True, )
    job_id = fields.Many2one(related='employee_id.job_id')
    doc_state = fields.Selection(related='employee_id.doc_state')
    cert_state = fields.Selection(related='employee_id.cert_state')
    project_id = fields.Many2one(related='employee_id.project_id')
    vacation_date = fields.Date(related='employee_id.last_leave_date')
    vacation_days = fields.Float(related='employee_id.last_leave_days')
    departure_date = fields.Date(string="Departure Date", required=True,default=date.today() )
    onboard_date = fields.Date(string="Onboard Start Date", required=False, )
    onboard_days = fields.Float(string="Onboard Days", compute='get_onboard_days')
    sick_leave = fields.Selection(related='employee_id.sick_leave')
    state = fields.Selection(related='crew_reassign_id.state')

    temp_type = fields.Many2many(related='job_id.job_type')
    job_type = fields.Many2one(comodel_name='hr.job.type', string="Job Type", required=False, domain="[('id','in',temp_type[0][2])]" )


    @api.multi
    def confirm_button_action(self):
        return {
            'name': _('Reassign Request'),
            'type': 'ir.actions.act_window',
            'res_model': 'reassign.line.confirm',
            'view_type': 'form',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_last_project':self.project_id.id,
                'default_reassign_id':self.crew_reassign_id.id,
                'default_employee_id':self.employee_id.id,
                'default_departure_date':self.departure_date,
            }
        }





    @api.onchange('temp_type')
    def onchange_temp_type(self):
        temp_list=[]
        print("UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        print(self.temp_type.id ,self.temp_type.ids , "UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        if self.temp_type.ids == []:
            print("IOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}
        else:
            for x in self.temp_type:
                temp_list.append(x.id)
            print("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}









    # @api.depends('employee_id')
    # def comp_start_d(self):
    #     projects_in = self.env['crew.in'].search([('project_id.id', '=', self.crew_reassign_id.project_id.id), ('state' ,'=', 'open')])
    #     for proj in projects_in:
    #         for line in proj.employee_ids:
    #             if line.employee_id.id == self.employee_id.id:
    #                 self.onboard_date = line.onboard_date


    @api.one
    def get_onboard_days(self):
        if self.onboard_date and self.departure_date:
            start_date = datetime.strptime(str(self.onboard_date), '%Y-%m-%d')
            end_date = datetime.strptime(str(self.departure_date), '%Y-%m-%d')
            period_days = end_date - start_date
            self.onboard_days = period_days.days

    @api.constrains('onboard_date', 'departure_date')
    def check_dates(self):
        if self.onboard_date and self.departure_date :
            if self.onboard_date > self.departure_date:
                raise UserError(_('OnBoard Date Must Be Before Departure Date.'))

    # @api.model
    # def create(self, values):
    #     res = super(CrewTransactionReassign, self).create(values)
    #     project_in = self.env['crew.in'].search([('state', '=', 'open'),('project_id', '!=', res.crew_reassign_id.project_id.id)])
    #     print("SSSSSSSSSSS")
    #     for proj in project_in:
    #         for line in proj.employee_ids:
    #             print(line.employee_id.id , res.employee_id.id , "eeeememmemmemmememem")
    #             if line.employee_id.id == res.employee_id.id:
    #                 res.onboard_date = line.onboard_date
    #     return res

    # @api.multi
    # def confirm_reassign_trans(self):
    #     for record in self:
    #         transaction = self.env['crew.transaction']
    #         vals = {
    #             'employee_id':record.employee_id.id,
    #             'crew_reassign_id':record.crew_reassign_id.id,
    #             'project_trans_id':record.crew_reassign_id.project_id.id,
    #             'onboard_date':record.onboard_date,
    #             'departure_date':record.departure_date,
    #             'onboard_days':record.onboard_days,
    #             'state':'reassign',
    #         }
    #         transaction.create(vals)
        #     project_in = self.env['crew.in'].search([('state', '=', 'open')])
        #     for proj in project_in:
    #     #         for mem in proj.employee_ids:
    #     #             if mem.employee_id.id == record.employee_id.id :
    #     #                 val = {
    #     #                     'employee_id': record.employee_id.id,
    #     #                     'crew_out_id': proj.crew_out.id,
    #     #                     'onboard_date': record.onboard_date,
    #     #                     'departure_date': record.departure_date,
    #     #                 }
    #     #                 crew_out = self.env['crew.transaction.out'].create(val)
    #     #                 crew_out.confirm_out()
    #     #     project_reassign = self.env['crew.in'].search([('project_id', '=', record.crew_reassign_id.project_id.id)], limit=1)
    #     #
    #     #     values = {
    #     #         'employee_id': record.employee_id.id,
    #     #         'crew_in_id': project_reassign.id,
    #     #         'onboard_date': record.departure_date,
    #     #     }
    #     #     crew_in = project_reassign.employee_ids.create(values)
    #     #     crew_in.confirm_in()
    #         record.unlink()



    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        projects_in = self.env['crew.in'].search([('project_id.id','=',self.crew_reassign_id.project_id.id) , ('state' ,'=', 'open')])
        employees = []
        for proj in projects_in:
            employees.append(proj.employee_ids.mapped('employee_id').ids)
        final_list = [item for employee in employees for item in employee]
        final_list = list(set(final_list))
        return {'domain': {'employee_id': [('id', 'in', final_list)]}}


class CrewTransaction(models.Model):
    _name = 'crew.transaction'
    _rec_name = 'employee_id'

    # @api.model
    # def _get_onboarddate(self):
    #
    #     emp_in = self.env['crew.transaction'].search([('employee_id.id', '=', self.employee_id.id) , ('project_id.id', '=',self.project_id.id) , ('state' , '=' , "in")]).temp_onboard_date
    #     print(emp_in.temp_onboard_date , "NNNNNNNNNNNNNNNNNNNNNNNNNNNN")
    #     if emp_in:
    #             return emp_in.temp_onboard_date


    balance = fields.Integer()
    crew_in_id = fields.Many2one(comodel_name="crew.in", string="Crews", required=False, )
    crew_out_id = fields.Many2one(comodel_name="crew.out", string="Crews", required=False, )
    transaction_date = fields.Char(string="Crew Transaction Date")
    labor_request_id = fields.Many2one(comodel_name="hr.crew.labor", string="Labor Request",)
    crew_reassign_id = fields.Many2one(comodel_name="crew.reassign", string="Crews", required=False, )
    project_trans_id = fields.Many2one(comodel_name="project.project", string="Project", required=False, )
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee Name", required=False, )
    job_id = fields.Many2one(related='employee_id.job_id')
    doc_state = fields.Selection(related='employee_id.doc_state')
    cert_state = fields.Selection(related='employee_id.cert_state')
    project_id = fields.Many2one(related='employee_id.project_id')
    vacation_date = fields.Date(related='employee_id.last_leave_date')
    vacation_days = fields.Float(related='employee_id.last_leave_days')
    departure_date = fields.Date(string="Departure Date", required=False, )
    onboard_date = fields.Date(string="Onboard Start Date", required=False, )
    onboard_days = fields.Float(string="Onboard Days", required=False, )
    temp_departure_date = fields.Date(string="Departure Date", required=False, )
    temp_onboard_date = fields.Date(string="Onboard Start Date", required=False,)
    time_sheet = fields.Boolean(string="Time Sheet" , default=False)
    past_work = fields.Integer(string="Work Days" ,)
    sick_leave = fields.Selection(related='employee_id.sick_leave')
    state = fields.Selection(string="Status", selection=[('in', 'IN'), ('out', 'OUT'), ('reassign', 'Reassign'), ],
                             required=False, )
    leave = fields.Char(string="Normal")
    crew_ids = fields.Many2one(comodel_name="hr.department", string="Crew", required=False, )
    # cont_crew = fields.Boolean(compute='crew_control')

    e_ot = fields.Boolean( default=False , compute='get_emp_out')
    reassign = fields.Char(string="Reassign")

    temp_type = fields.Many2many(related='job_id.job_type')
    job_type = fields.Many2one(comodel_name='hr.job.type', string="Job Type", required=False, domain="[('id','in',temp_type[0][2])]" )

    @api.onchange('temp_type')
    def onchange_temp_type(self):
        temp_list=[]
        print("UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        print(self.temp_type.id ,self.temp_type.ids , "UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        if self.temp_type.ids == []:
            print("IOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}
        else:
            for x in self.temp_type:
                temp_list.append(x.id)
            print("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}






    #
    # @api.depends('state','departure_date')
    # def crew_control(self):
    #     if self.state == 'in' and self.departure_date:
    #         print("QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ")
    #         self.departure_date = False
    #         self.cont_crew = True
    #     print(self.departure_date)

    @api.multi
    def action_cancel(self):
        vals_out=[]
        vals_in=[]
        crew_in = self.env['crew.in']
        current_user= self.env['res.users'].search([('id' , '=' , self.env.uid)])

        if self.state == "out":
            vals_out.append((0, 0, {
                'employee_id': self.employee_id.id,
                'labor_request_id': self.labor_request_id.id,
                'onboard_date': self.onboard_date,
                'departure_date': self.departure_date,
                'trans_cancelled': True,
                'trans_confirmed_d': "Tarnsaction Canceled Before in : " + str(datetime.now()) + " By : " + str(
                    current_user.name) + " And Confirmed Again In :",
                'is_confirm_out': False,
                'job_id': self.job_id.id,
            }))
            vals_in.append((0, 0, {
                'employee_id': self.employee_id.id,
                'labor_request_id': self.labor_request_id.id,
                'onboard_date': self.onboard_date,
                'trans_cancelled': True,
                'trans_confirmed_d': "Tarnsaction Canceled Before in : " + str(datetime.now()) + " By : " + str(
                    current_user.name) + " And Confirmed Again In :",
                'is_confirm': False,
                'job_id': self.job_id.id,

            }))
            # if self.leave == "Normal Leave":
            #     self.env['hr.holidays'].search([('id' , '=' , self.employee_id.last_vacation_id.id)]).unlink()
            #     self.employee_id.last_vacation_id.unlink()
            #     self.employee_id.last_leave_date.unlink()
            #     self.employee_id.last_leave_days.unlink()
            #     self.employee_id.vacation = False
            #
            # elif self.leave == "Sick Leave":
            # leave_type = self.env.ref('hr_holidays.holiday_status_sl')
            # leaves = self.env['hr.holidays'].search(
            #     [('employee_id', '=', self.employee_id.id), ('holiday_status_id', '=', leave_type.id),
            #      ('state', 'in', ['validate', 'validate1'])])
            # if leaves:
            #     leaves.unlink()
            # if self.employee_id.last_vacation_id:
            # self.employee_id.last_leave_date.unlink()
            # self.employee_id.last_leave_days.unlink()
            # self.employee_id.vacation = False

            # self.crew_out_id.write({'employee_ids':vals_out})
            for trans_in in self.env['crew.in'].search([('project_id' , '=' , self.project_id.id)]) :
                print(trans_in , "transtranstranstranstranstrans")
                trans_in.write({'employee_ids': vals_in})
            for trans_out in self.env['crew.transaction'].search([('crew_out_id' , '=' , self.crew_out_id.id),('employee_id' , '=' , self.employee_id.id)]):
                trans_out.unlink()
        elif self.state == "in":
            vals_in.append((0, 0, {
                'employee_id': self.employee_id.id,
                'labor_request_id': self.labor_request_id.id,
                'onboard_date': self.onboard_date,
                'trans_cancelled': True,
                'trans_confirmed_d': "Tarnsaction Canceled Before in : " + str(datetime.now()) + " By : " + str(
                    current_user.name) + " And Confirmed Again In :",
                'is_confirm': False,
                'job_id': self.job_id.id,

            }))
            if self.crew_out_id:
                vals_out.append((0, 0, {
                    'employee_id': self.employee_id.id,
                    'labor_request_id': self.labor_request_id.id,
                    'onboard_date': self.onboard_date,
                    'departure_date': self.departure_date,
                    'trans_cancelled': True,
                    'trans_confirmed_d': "Tarnsaction Canceled Before in : " + str(datetime.now()) + " By : " + str(
                        current_user.name) + " And Confirmed Again In :",
                    'is_confirm_out': False,
                    'job_id': self.job_id.id,

                }))
                self.crew_in_id.write({'employee_ids': vals_in})
                for trans_in in self.env['crew.transaction'].search(
                        [('crew_in_id', '=', self.crew_in_id.id), ('employee_id', '=', self.employee_id.id)]):
                    trans_in.unlink()
                for trans_out in self.env['crew.transaction'].search(
                        [('crew_out_id', '=', self.crew_out_id.id), ('employee_id', '=', self.employee_id.id)]):
                    trans_out.unlink()

            else:
                self.crew_in_id.employee_ids.search([('employee_id', '=', self.employee_id.id)]).unlink()
                self.crew_in_id.write({'employee_ids': vals_in})
                for trans_in in self.env['crew.transaction'] .search([('crew_in_id' , '=' , self.crew_in_id.id),('employee_id' , '=' , self.employee_id.id)]) :
                    trans_in.unlink()



    @api.depends('crew_out_id')
    def get_emp_out(self):
        if self.crew_out_id and self.state != 'out':
            self.e_ot = True





class out_line_confirm(models.Model):
    _name = 'out.line.confirm'


    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee Name", required=True, )
    departure_date = fields.Date(string="Debarture Date", required=True, )
    normal_leave = fields.Boolean(string="Normal" , default=True)
    sick_leave = fields.Boolean(string="Sick" , default=False)
    out_id =  fields.Many2one(comodel_name="crew.out")


    @api.onchange('normal_leave' )
    def onchange_normal_leave(self):

            if self.sick_leave and self.normal_leave:
                    self.normal_leave  = True
                    self.sick_leave  = False
            if not self.sick_leave and self.normal_leave :
                self.normal_leave = True
                self.sick_leave = False

    @api.onchange('sick_leave')
    def onchange_sick_leave(self):
            if self.normal_leave and self.sick_leave:
                    self.sick_leave  = True
                    self.normal_leave  = False
            if not self.normal_leave and self.sick_leave :
                self.sick_leave = True

    @api.multi
    def confirm_leave_out(self):
        holiday_status_id = 0
        date_format = '%Y-%m-%d'
        # d = datetime.strptime(self.departure_date, date_format).date()
        #
        # newdate_from = fields.Date.from_string(self.departure_date) + timedelta(days=1)

        newdate_from = (datetime.strptime(self.departure_date, date_format) + relativedelta(days=+1))

        for x in self.env['hr.holidays.status'].search([('name', '=', "Sick Leaves")]):
            holiday_status_id = x.id


        # out_id = self.env['crew.out'].browse(self.env.context.get('active_ids'))

        if self.normal_leave:
            leave = "Normal Leave"
            for out in self.out_id.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]):
                out.update({'departure_date':self.departure_date})
                out.confirm_out(leave)
        if self.sick_leave:
            leave = "Sick Leave"
            for out in self.out_id.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]):
                out.temp = True
                out.update({'departure_date':self.departure_date})
                out.confirm_out(leave)
            return {
                'type': 'ir.actions.act_window',
                'res_model': 'hr.holidays',
                'view_type': 'form',
                'view_mode': 'form',
                'context': {
                    'default_holiday_status_id': holiday_status_id,
                    'default_employee_id': self.employee_id.id,
                    'default_date_from': str(newdate_from)
                },
                'target': 'new'}








class reassign_line_confirm(models.Model):
    _name = 'reassign.line.confirm'

    employee_id = fields.Many2one(comodel_name="hr.employee", string="Employee Name", required=False, )
    last_project = fields.Many2one(comodel_name="project.project" , required=True,)
    project_id = fields.Many2one(comodel_name="project.project" , required=True,)
    departure_date = fields.Date(string="Onboard Start Date", required=True, )
    onboard_date = fields.Date(string="Onboard Start Date", required=True, )
    reassign_id = fields.Many2one(comodel_name='crew.reassign' )

    @api.constrains('departure_date' , 'onboard_date')
    def cons_reassign_period(self):
        allowed_diff = 0
        for limit in self.env['crew.settings'].search([]):
            allowed_diff = limit.reassign_per
            print(limit.reassign_per ,"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        start_date = datetime.strptime(str(self.onboard_date), '%Y-%m-%d')
        end_date = datetime.strptime(str(self.departure_date), '%Y-%m-%d')
        diff_days = start_date - end_date
        print(diff_days.days , "YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY")
        if diff_days.days >= allowed_diff :
            raise UserError(_("%s onboard date in %s is %s and the departure date from %s is %s .\n"
                              "Allowed Reassign Differance is %s .") %
                            (self.employee_id.name,self.project_id.name , self.onboard_date , self.last_project.name ,self.departure_date , allowed_diff))

    @api.one
    def confirm_reassign(self):
        employee_out=[]
        employee_in=[]
        onboard_days=0
        employee_out.append(
            (0, 0, {
                    'employee_id':self.employee_id.id,
                    'job_id': self.employee_id.job_id.id,
                    'project_id': self.last_project.id,
                    'departure_date':self.departure_date,
                    'is_reassign' : True,
                    'reassign': "Reassigned"
            }))
        employee_in.append(
            (0, 0, {
                    'employee_id':self.employee_id.id,
                    'job_id': self.employee_id.job_id.id,
                    'project_id': self.project_id.id,
                    'onboard_date':self.onboard_date,
                    'departure_date':False,
                    'reassign': "Reassigned"

            }))
        projects_out = self.env['crew.out'].search([('project_id.id','=',self.last_project.id) , ('state' ,'=', 'open')])
        projects_in = self.env['crew.in'].search([('project_id.id','=',self.project_id.id), ('state' ,'=', 'open')])

        for trans in self.env['crew.transaction'].search([('project_trans_id.id','=',self.last_project.id),('employee_id.id','=',self.employee_id.id),('state','=','in')]):
            trans.write({'reassign':"Employee Reassigned To Another Project",
                         'departure_date': self.departure_date,
                         })


        for proj in projects_out:
            proj.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).unlink()
            proj.write({'employee_ids':employee_out})
            proj.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).confirm_out("Reassigned")


            # proj.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)])
            # proj.write({'employee_ids':employee_out})
            # print(proj.employee_ids , "employee_ids")
            # proj.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).confirm_out()


        for proj in projects_in:
            proj.write({'employee_ids':employee_in})
            proj.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).confirm_in()

        #
        for record in self.reassign_id :
            transaction = self.env['crew.transaction']
            for xx in record.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]):
                onboard_days = xx.onboard_days
            vals = {
                # 'employee_id':record.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).employee_id.id,
                'employee_id':self.employee_id.id,
                'crew_reassign_id':self.reassign_id.id,
                'project_trans_id':self.project_id.id,
                'onboard_date':self.onboard_date,
                'departure_date':self.departure_date,
                'onboard_days':onboard_days,
                'state':'reassign',
                'reassign': "Reassigned to project:" + str(self.project_id.name),
                'crew_ids': record.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).employee_id.department_id.id

            }

            transaction.create(vals)
            record.employee_ids.search([('employee_id.id' , '=' , self.employee_id.id)]).unlink()

