# -*- coding: utf-8 -*-
import time

from datetime import datetime,timedelta , date
# from dateutil.relativedelta import relativedelta
from datetime import timedelta
from dateutil.relativedelta import relativedelta
from odoo import api, fields, models


class TimeSheetBatch(models.Model):
    _name = 'hr.timesheet.crew.batch'
    _rec_name = 'name'
    _description = 'New Batch'

    def _get_user(self):
        return self.env.user.id

    name = fields.Char(string="REF", required=False, compute='get_ref' )
    # current_user = fields.Many2one(comodel_name='res.users' ,default=lambda self: self.env.uid)
    # current_date = fields.Date(default=date.today())
    # date_from = fields.Date(string="Date From", required=False,default=time.strftime('%Y-%m-16'), )
    # date_to = fields.Date(string="Date To", required=False,
    #                       default=str(datetime.now() + relativedelta.relativedelta(months=+1, day=1, days=+14))[:10],)
    date_from = fields.Date(string="Date From", required=False , default=str(datetime.now() + relativedelta(months=-1, day=1, days=+15))[:10])
    date_to = fields.Date(string="Date To", required=False,default=time.strftime('%Y-%m-15'), )
    project_id = fields.Many2one(comodel_name="project.project", string="Project", )
    project_type_id = fields.Selection(related='project_id.type_ids' , readonly=True)
    project_shift_type_id = fields.Many2one(related='project_id.proj_shift_type_id' , readonly=True)
    location_id = fields.Many2one(related='project_id.location_id' , readonly=True)
    crew_id = fields.Many2one(comodel_name="hr.department", string="Crew", domain=[('is_crew', '=', True)],
                                required=False, )
    sheets_ids = fields.One2many(comodel_name="hr.timesheet.crew", inverse_name="batch_id", string="TimeSheets", required=False, )
    state = fields.Selection(string="Status", selection=[('draft', 'Draft'),('confirm', 'Computed'),('request_approval', 'Approve'),('approved', 'Confirm'), ('close', 'Payslips'), ], required=False,default='draft' )
    crew_m_group_approve = fields.Boolean(required=False,compute='get_crew_manger')
    user_id = fields.Many2one(comodel_name="res.users", string="Completed By",readonly=True,default=_get_user, required=False, )

    vendor_flag = fields.Boolean(string="Vendor" ,default=False)
    payslip_flag = fields.Boolean(string="Payslip" ,default=False)

    # timesheet_edit = fields.Boolean(string="Edit" ,default=False ,compute='get_timesheet_edit')
    #
    # @api.depends('project_id')
    # def get_timesheet_edit(self):
    #     # self.timesheet_edit = self.project_id.allownaces
    #     self.timesheet_edit = True


    @api.depends('state' ,'user_id')
    def get_crew_manger(self):
        if self.state == 'request_approval':
            crew_m = self.env['res.groups'].search(
                [('name', '=', 'crew manager')])

            is_crew_m = self.env.user.id in crew_m.users.ids
            if is_crew_m == True:
                self.crew_m_group_approve = True
            else:
                self.crew_m_group_approve = False

    @api.multi
    def request_app_buttun(self):
        self.update({'state' : "request_approval" })

    @api.multi
    def approve_button(self):
        self.update({'state': "approved"})

    @api.one
    @api.depends('crew_id')
    def get_ref(self):
        current_user = ''
        for user in self.env['res.users'].search([('id' , '=' , self.env.uid)]):
            current_user = user.name
        self.name = str(current_user) + "/" +str(self.crew_id.name) + "/" + str(date.today())

    @api.multi
    def compute_sheet(self):
        date_format = '%Y-%m-%d'
        timesheet = self.env['hr.timesheet.crew']
        if self.project_id :
            employees = self.env['crew.transaction'].search(
                [('project_trans_id', '=',self.project_id.id ), ('temp_onboard_date', '>=', self.date_from)  , ('temp_onboard_date', '<=', self.date_to)  , ('employee_id.department_id' , '=' , self.crew_id.id ), ('state' , 'in' , ['in'])])
        else:
            employees = self.env['crew.transaction'].search(
                [('temp_onboard_date', '>=', self.date_from) , ('temp_onboard_date', '<=', self.date_to) , ('employee_id.department_id' , '=' , self.crew_id.id ) , ('state' , 'in' , ['in'])])

        for employee in employees:
                print(employee.crew_out_id , employee.employee_id.name , employee.state ,"TTTTTTTTTTTTTTTTTTTTTTTTTTTT")
                # if employee.crew_out_id and employee.state == 'in':
                #     continue
                offshore = 0
                temp_date_from = 0
                temp_date_to = date.today()
                date_f_x2 = 0
                date_to = 0


                d1 = datetime.strptime(employee.temp_onboard_date, date_format).date()
                # d3 = datetime.strptime(date.today(), date_format).date()
                if employee.departure_date:
                    d2 = datetime.strptime(employee.departure_date, date_format).date()
                r_onboard_date = datetime.strptime(employee.onboard_date, date_format).date()
                v_date_to = datetime.strptime(self.date_to, date_format).date()

                v_date_from = datetime.strptime(self.date_from, date_format).date()
                print(employee.id , "employee.idemployee.idemployee.id")
                if employee.departure_date >= self.date_to :
                    print(employee.departure_date , "111111111111111111111111111111")
                    temp_date_to = self.date_to
                    r = v_date_to - d1
                else:
                    temp_date_to = employee.departure_date
                    print(employee.departure_date , "222222222222222222222222222222222")
                    if employee.departure_date:
                        print(employee , "eee")
                        print(employee.departure_date , "if")
                        if temp_date_to < employee.temp_onboard_date:
                            r = v_date_to - d1
                        else:
                            r = d2 - d1
                    elif not employee.departure_date and self.date_to > str(date.today())  :
                        print("elif")

                        r = v_date_to - d1
                    else:
                        print("else")

                        r = v_date_to - d1

                # print(self.project_id.proj_type_id.work_days , "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
                print(employee.employee_id , employee.past_work , r.days , "traaaaaaaans")
                if (employee.past_work + r.days) > self.project_id.location_id.work_days:
                # if (employee.onboard_days) > self.project_id.location_id.work_days:
                    print(employee.employee_id , employee.past_work , r.days , "greatttttttter")
                    if offshore == 0:
                        offshore = (employee.past_work + r.days) - self.project_id.location_id.work_days +1
                    else:
                        offshore = (employee.past_work + r.days) - self.project_id.location_id.work_days
                    date_f_x2 = r_onboard_date + timedelta(days=self.project_id.location_id.work_days)
                print(temp_date_to , "UUUUUUUUUUEEEEEEE")
                if not temp_date_to:
                    date_to = self.date_to
                else:
                    date_to = temp_date_to
                if temp_date_to < employee.temp_onboard_date:
                        vals={
                            'batch_id':self.id,
                            'employee_id':employee.employee_id.id,
                            'job_id':employee.employee_id.job_id,
                            'days':r.days + 1,
                            'offshore':offshore,
                            'job_type': employee.job_type.id,
                            'state':employee.state,
                            'date_from_2x':date_f_x2,
                            'project_id':employee.project_trans_id.id,
                            'date_from':employee.temp_onboard_date,
                            'date_to': date_to,

                        }
                else:
                        vals={
                            'batch_id':self.id,
                            'employee_id':employee.employee_id.id,
                            'job_id':employee.employee_id.job_id,
                            'job_type': employee.job_type.id,
                            'days':r.days + 1,
                            'offshore':offshore,
                            'state':employee.state,
                            'date_from_2x':date_f_x2,
                            'project_id':employee.project_trans_id.id,
                            'date_from':employee.temp_onboard_date,
                            'date_to':date_to,
                        }
                timesheet.create(vals)
        self.write({'state':'confirm'})

    @api.multi
    def vendor_bill(self):
        date_format = '%Y-%m-%d'
        vals = []
        journal = self.env['account.journal']
        if not self.env['account.journal'].search([('name' ,'=', 'Vendor Bills'),('code' , '=' , 'BILL'),('type' ,'=', 'purchase')]):
            print("NNNNNNNNNNNoo journal")
            journal = self.env['account.journal'].create({'name': 'Vendor Bills', 'code': 'BILL', 'type': 'purchase', })
        else:
            print("Yyyyyyyyyyyyyyyyyeees journal")
            journal = self.env['account.journal'].search([('name' ,'=', 'Vendor Bills'),('code' , '=' , 'BILL'),('type' ,'=', 'purchase')])
        if self.sheets_ids:
            for employee in self.sheets_ids:
                if employee.employee_id.out_source:
                        invoice_line_data = {
                            'product_id': employee.employee_id.products.id,
                            'quantity': 1.0,
                            'name': employee.employee_id.name,
                            'price_unit': employee.employee_id.outsource_rate,
                            'currency_id': employee.employee_id.currency_id.id,
                            'account_id': employee.employee_id.products.categ_id.property_account_expense_categ_id.id,
                            'duration' : employee.days,
                        }

                        invoice = self.env['account.invoice'].create({
                            'name': "Vendor Invoice",
                            'date_invoice': date.today(),
                            'type': 'in_invoice',
                            'partner_id': employee.employee_id.vendors.id,
                            'account_id': employee.employee_id.vendors.property_account_payable_id.id,
                            'journal_id': journal.id,
                            'currency_id': employee.employee_id.currency_id.id,
                            # 'company_currency_id': employee.employee_id.currency_id.id,
                            'invoice_line_ids': [(0, 0, invoice_line_data)],
                        })

                        for trans in self.env['crew.transaction'].search(
                                [('project_trans_id', '=', self.project_id.id),
                                 ('temp_onboard_date', '>=', self.date_from),
                                 ('employee_id', '=', employee.employee_id.id), ]):
                            if employee.date_to:
                                date_to = datetime.strptime(employee.date_to, date_format)
                                trans.write({'temp_onboard_date': date_to + relativedelta(days=+1),
                                             'past_work': trans.past_work + int(employee.days),
                                             })
                            else:
                                date_to = datetime.strptime(self.date_to, date_format)
                                trans.write({'temp_onboard_date': date_to + relativedelta(days=+1),
                                             'past_work': trans.past_work + int(employee.days),
                                             })
            self.update({'vendor_flag': True})



    @api.multi
    def Compute_payslip(self):
        date_format = '%Y-%m-%d'
        vals=[]
        holiday=[]
        if self.sheets_ids:
            for employee in self.sheets_ids:
                if employee.employee_id.out_source != True:
                    # for payroll in employee.employee_id:
                    vals.append(
                        (0, 0, {
                            'employee_id' : employee.employee_id.id,
                            'project_id': employee.project_id.id,
                            'job_id': employee.job_id.id,
                            'job_type': employee.job_type.id,
                            'date_from': employee.date_from,
                            'date_to': employee.date_to,
                            'performance': employee.performance,
                            'days': employee.days,
                            'offshore': employee.offshore,
                            'state': employee.state,
                            'date_from_2x': employee.date_from_2x,
                            'breakfast': employee.breakfast,
                            'lunch': employee.lunch,
                            'dinner': employee.dinner,
                            'lodge': employee.lodge,
                        }))
                    # holiday.append(
                    #     (0, 0, {
                    #     'name': "Timesheet " + str(employee.project_id.name),
                    #     'holiday_status_id': self.env['hr.holidays.status'].search([('name', '=', 'Crew')]),
                    #     'date_from': employee.date_from,
                    #     'date_to': employee.date_to,
                    #     'project_id': employee.project_id.id,
                    #     'employee_id': employee.employee_id.id,
                    #     'department_id': employee.employee_id.department_id.id
                    # }))
                    # print(holiday , "holidayholidayholiday")
                    employee.employee_id.write({'payslip_sheet': vals})
                    vals=[]
                    for trans in self.env['crew.transaction'].search(
                        [('project_trans_id', '=', self.project_id.id),
                         ('temp_onboard_date', '>=', self.date_from),('employee_id', '=', employee.employee_id.id),]):
                        if employee.date_to:
                            date_to = datetime.strptime(employee.date_to, date_format)
                            trans.write({'temp_onboard_date' :date_to + relativedelta(days=+1),
                                         'past_work' : trans.past_work + int(employee.days),
                                         })
                        else:
                            date_to = datetime.strptime(self.date_to, date_format)
                            trans.write({'temp_onboard_date' :date_to + relativedelta(days=+1),
                                         'past_work' : trans.past_work + int(employee.days),
                                         })
                    # holiday.append({
                    #     'name': "Timesheet " + str(employee.project_id.name),
                    #     'holiday_status_id': self.env['hr.holidays.status'].search([('name', '=', 'Crew')]),
                    #     'date_from': employee.date_from,
                    #     'date_to': employee.date_to,
                    #     'project_id': employee.project_id.id,
                    #     'employee_id': employee.employee_id.id,
                    #     'department_id': employee.employee_id.department_id.id
                    # })
                    print(holiday , "holidayholidayholiday")
                    self.env['hr.holidays'].create({
                        'name' : "Timesheet " + str(employee.project_id.name),
                        'holiday_status_id' : self.env['hr.holidays.status'].search([('name' , '=' , 'Crew')]).id,
                        'date_from' : employee.date_from,
                        'date_to' : employee.date_to,
                        'project_id' : employee.project_id.id,
                        'employee_id' : employee.employee_id.id,
                        'department_id' : employee.employee_id.department_id.id
                    })
        self.write({'state':'close'})



    @api.onchange('project_id')
    def change_project_id(self):
        val=[]
        for proj in self.env['project.crew'].search([('project_id' , '=' , self.project_id.id)]):
            for dep in proj.assignd_crew_ids:
                val.append(dep.crew_id.id)
        return {'domain': {'crew_id': [('id', 'in', val)]}}






