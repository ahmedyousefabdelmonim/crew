# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import datetime,timedelta , date
import time
from datetime import timedelta
from dateutil.relativedelta import relativedelta

class HrTimeSheet(models.Model):
    _name = 'hr.timesheet.crew'
    _rec_name = 'employee_id'
    _description = 'New TimeSheet'

    batch_id = fields.Many2one(comodel_name="hr.timesheet.crew.batch", string="Name", required=False, )
    employee_payslip = fields.Many2one(comodel_name="hr.employee", string="Name", required=False, )
    employee_id = fields.Many2one(comodel_name="hr.employee", string="Name", required=False, )
    job_id = fields.Many2one(related='employee_id.job_id')
    temp_type = fields.Many2many(related='job_id.job_type')
    job_type = fields.Many2one(comodel_name='hr.job.type', string="Job Type", required=False, domain="[('id','in',temp_type[0][2])]" )
    performance = fields.Integer(string="Performance", required=False, default=100)
    days = fields.Integer(string="Days", required=False, )
    offshore = fields.Integer(string="2x Offshore", required=False, )
    project_id = fields.Many2one(comodel_name="project.project", string="Project", required=False, )
    # proj_type_id = fields.Many2one(related='project_id.location_id')
    location_id = fields.Many2one(related='project_id.location_id')
    date_from = fields.Date(string="1st", required=False, )
    date_to = fields.Date(string="Last", required=False, )
    date_from_2x = fields.Date(string="2x Start", required=False, )
    breakfast = fields.Float(string="Breakfast",  required=False, )
    lunch = fields.Float(string="Lunch",  required=False, )
    dinner = fields.Float(string="Dinner",  required=False, )
    lodge = fields.Float(string="Lodge",  required=False, )
    emp = fields.Boolean()
    state = fields.Selection(string="Status", selection=[('in', 'IN'), ('out', 'OUT'), ('reassign', 'Reassign'), ],
                             required=False, )
    current_month = fields.Integer(string="Month" , compute='get_current_moth')
    current_year = fields.Integer(string="Year" , compute='get_current_moth')

    # timesheet_edit = fields.Boolean(string="Edit",related='project_id.allownaces')
    timesheet_edit = fields.Boolean(string="Edit" ,default=False ,compute='get_timesheet_edit')

    @api.one
    @api.depends('project_id')
    def get_timesheet_edit(self):
        self.timesheet_edit = self.project_id.allownaces or False
        # self.timesheet_edit = True


    @api.one
    @api.depends('date_to')
    def get_current_moth(self):
        date_format = '%Y-%m-%d'
        if self.date_to:
            d1 = datetime.strptime(self.date_to, date_format).date()
            self.current_month = d1.month
            self.current_year = d1.year

    # # temp = fields.Boolean(default=False , compute='get_employee_job_type')
    @api.onchange('temp_type')
    def onchange_temp_type(self):
        temp_list=[]
        print("UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        print(self.temp_type.id ,self.temp_type.ids , "UUUUUUUUUUUUUYGGHGGGGGGGGGGGGGGGGG")
        if self.temp_type.ids == []:
            print("IOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}
        else:
            for x in self.temp_type:
                temp_list.append(x.id)
            print("IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII")
            return {'domain': {
                'job_type':[('id','in',temp_list)]
            }}

