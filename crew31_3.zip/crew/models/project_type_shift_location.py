# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions ,_

class project_type(models.Model):
    _name = 'project.type'

    name = fields.Char(string="Name",  )
    work_days = fields.Integer(string="Work Days", )



class project_shift_type(models.Model):
    _name = 'shift.type'

    name = fields.Char(string="Name",  )


class project_location(models.Model):
    _name = 'project.location'

    name = fields.Char(string="Name",  )


class project_bonus(models.Model):
    _name = 'project.bonus'

    job_titles = fields.Many2one(comodel_name="hr.job" ,string="Title",  )
    bonus = fields.Float(string="Bonus",  )

    project_id = fields.Many2one(comodel_name="project.project",  required=False, )



class project_custom(models.Model):
    _inherit = 'project.project'
    # type_ids = fields.Many2many('project.task.type', 'project_task_type_rel', 'project_id', 'type_id', string='Tasks Stages' , invisible=True)
    # type_ids = fields.Selection(selection=[('lump_sum' , 'Lump Sum') , ('daily_rate' , 'Daily Rate')] , string='Tasks Stages' , invisible=True)
    # proj_type_id = fields.Many2one(comodel_name="project.type", string="Project Type", required=False, )
    type_ids = fields.Selection(selection=[('lump_sum' , 'Lump Sum') , ('daily_rate' , 'Daily Rate')] , string='Project Type')
    proj_shift_type_id = fields.Many2one(comodel_name="shift.type", string="Shift Type", required=False, )
    # proj_location_id = fields.Many2one(comodel_name="project.location", string="Project Location", required=False, )

    project_bonus_ids = fields.One2many(comodel_name="project.bonus", inverse_name='project_id' , string="Project Bonus", required=False, )

    location_id = fields.Many2one(string="Location",comodel_name="project.type",required=False, )

    crew_count = fields.Integer(string="MOP Num", required=False,default=0  , compute='get_open_crew')


    @api.depends('crew_count')
    def get_open_crew(self):
        crew = self.env['crew.in'].search([('project_id' , '=' , self.id)])
        self.crew_count =  len(crew)


    @api.multi
    def action_view_crews(self):

            domain = [('project_id', '=', self.id)]
            return {
                'name': _('Crews'),
                'type': 'ir.actions.act_window',
                'res_model': 'crew.in',
                'view_type': 'form',
                'view_mode': 'tree,form',
                'domain': domain,
                'target': 'new'
            }

