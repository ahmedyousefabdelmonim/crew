# -*- coding: utf-8 -*-

from odoo import models, fields, api, exceptions

class department_crew(models.Model):
    _inherit = 'hr.department'

    is_crew = fields.Boolean(string="Crew",  )

    employee_ids = fields.One2many(comodel_name="hr.employee", inverse_name="department_id", string="Employees", required=False, )
    crew_admin_id = fields.Many2one(comodel_name="hr.employee", string="Crew Admin", required=False, )
    # job_type = fields.Many2many(comodel_name="hr.employee", string="Crew Admin", required=False, )




