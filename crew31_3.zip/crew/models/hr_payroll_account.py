#-*- coding:utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from odoo.tools import float_compare, float_is_zero


class HrPayslipLine(models.Model):
    _inherit = 'hr.payslip.line'


    duration_salary_comp = fields.Integer(string="Duration", required=False, readonly=True , compute='get_duration' )
    total_egp = fields.Float(compute='compute_total_egp', string='Total EGP', readonly=True)

    @api.one
    @api.depends('total')
    def compute_total_egp(self):
        # if self.env['res.currency'].search([('name', '=', 'EGP')]).rate != 0 :
            self.total_egp = self.total * self.env['res.currency'].search([('name', '=', 'EGP')]).rate

    @api.one
    @api.depends('name' , 'salary_rule_id' )
    def get_duration(self):



        if self.salary_rule_id.location_id.name == "Local":
            if self.salary_rule_id.allowance == "breakfast":
                self.duration_salary_comp = self.slip_id.breakfast_loc
            if self.salary_rule_id.allowance == "lunch":
                self.duration_salary_comp = self.slip_id.lunch_loc
            if self.salary_rule_id.allowance == "dinner":
                self.duration_salary_comp = self.slip_id.dinner_loc
            if self.salary_rule_id.allowance == "lodge":
                self.duration_salary_comp = self.slip_id.lodge_loc
            if self.salary_rule_id.allowance == "away":
                self.duration_salary_comp = self.slip_id.away_loc
            if self.salary_rule_id.allowance == "car":
                self.duration_salary_comp = self.slip_id.car_loc
        elif self.salary_rule_id.location_id.name == "International":
            if self.salary_rule_id.allowance == "breakfast":
                self.duration_salary_comp = self.slip_id.breakfast_inter
            if self.salary_rule_id.allowance == "lunch":
                self.duration_salary_comp = self.slip_id.lunch_inter
            if self.salary_rule_id.allowance == "dinner":
                self.duration_salary_comp = self.slip_id.dinner_inter
            if self.salary_rule_id.allowance == "lodge":
                self.duration_salary_comp = self.slip_id.lodge_inter
            if self.salary_rule_id.allowance == "away":
                self.duration_salary_comp = self.slip_id.away_inter
            if self.salary_rule_id.allowance == "car":
                self.duration_salary_comp = self.slip_id.car_inter

    def _get_partner_id(self, credit_account):
        """
        Get partner_id of slip line to use in account_move_line
        """
        # use partner of salary rule or fallback on employee's address
        register_partner_id = self.salary_rule_id.register_id.partner_id
        partner_id = register_partner_id.id or self.slip_id.employee_id.address_home_id.id
        if credit_account:
            if register_partner_id or self.salary_rule_id.account_credit.internal_type in ('receivable', 'payable'):
                return partner_id
        else:
            if register_partner_id or self.salary_rule_id.account_debit.internal_type in ('receivable', 'payable'):
                return partner_id
        return False



# class HrSalaryRule(models.Model):
#     _name = 'allowance.type'
#
#     name = fields.Char(string="Allowance")


class HrSalaryRule(models.Model):
    _inherit = 'hr.salary.rule'

    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account')
    account_tax_id = fields.Many2one('account.tax', 'Tax')
    account_debit = fields.Many2one('account.account', 'Debit Account', domain=[('deprecated', '=', False)])
    account_credit = fields.Many2one('account.account', 'Credit Account', domain=[('deprecated', '=', False)])

    location_id = fields.Many2one(string="Location",comodel_name="project.type",required=False, )
    allowance = fields.Selection(string="Allowance",selection=[('breakfast','Breakfast'),('lunch','Lunch'),('dinner','Dinner'),('lodge','Lodge'),('away','Away'),('car','Car'),],required=False, )
    # job_type = fields.Many2many(comodel_name='hr.job.type', string="Job Type", required=False, )

class HrContract(models.Model):
    _inherit = 'hr.contract'
    _description = 'Employee Contract'

    analytic_account_id = fields.Many2one('account.analytic.account', 'Analytic Account')
    journal_id = fields.Many2one('account.journal', 'Salary Journal')

class HrPayslipRun(models.Model):
    _inherit = 'hr.payslip.run'
    _description = 'Payslip Run'

    journal_id = fields.Many2one('account.journal', 'Salary Journal', states={'draft': [('readonly', False)]}, readonly=True,
        required=True, default=lambda self: self.env['account.journal'].search([('type', '=', 'general')], limit=1))
