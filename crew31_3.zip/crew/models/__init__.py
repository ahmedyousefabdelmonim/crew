# -*- coding: utf-8 -*-

from . import crew
from . import project
from . import project_type_shift_location
from . import crew_change
from . import hr_job
from . import labor_request
from . import hr_employee
from . import hr_timesheet
from . import timesheet_crew_batch
from . import hr_payslip
from . import settings
from . import rep_wiz
from . import hr_payroll_account
from . import offshore
