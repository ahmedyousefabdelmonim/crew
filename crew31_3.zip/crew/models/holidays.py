# -*- coding: utf-8 -*-

from datetime import datetime,timedelta
from datetime import date
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from dateutil.relativedelta import relativedelta
from odoo import tools, _


class HrHolidays_inherit(models.Model):
    _inherit = 'hr.holidays'


    number_of_days_temp = fields.Float('Allocation', copy=False, compute='compute_days')

    @api.one
    @api.depends('date_to', 'date_from')
    def compute_days(self):

        date_from = self.date_from
        date_to = self.date_to

        # Compute and update the number of days
        if (date_to and date_from) and (date_from <= date_to):
            self.number_of_days_temp = self._get_number_of_days(date_from, date_to, self.employee_id.id)
        else:
            self.number_of_days_temp = 0



