# -*- coding: utf-8 -*-</record>

{
    'name': "Crew",

    'summary': """
        Crew
        """,
    'sequence': 1,
    'images': [],
    'installable': True,
    'application': True,
    'author': "GO TO MARKET DYNAMICS",
    'website': "http://www.g2mdx.com/",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'report', 'hr','mail' ,'hr_payroll', 'project','hr_holidays','employee_certifications_expiry','employee_documents_expiry' ,'hr_holidays_leave_repeated' , 'hr_holidays_leave_auto_approve' ],
    'data': [
        # 'security/ir.model.access.csv',
        'datas/data_view.xml',
        'datas/crew_holiday_data.xml',
        'datas/crew_project_type_data.xml',
        'datas/crew_cron.xml',
        'views/crew.xml',
        'views/crew_change.xml',
        'views/project.xml',
        'views/project_type_shift_location.xml',
        'views/labor_view.xml',
        'views/crew_settings_view.xml',
        'views/hr_employee_view.xml',
        'views/hr_timesheet_view.xml',
        'views/timesheet_crew_batch_view.xml',
        'views/hr_payroll_view.xml',
        'views/hr_job_view.xml',
        'views/rep_wiz_view.xml',
        'views/holiday_rep_temp.xml',
        'views/holiday_report.xml',
        'views/hr_payroll_account_views.xml',
        'views/hr_offshore_view.xml',
    ],
    'application': True,
    'qweb': [
    ],
}
